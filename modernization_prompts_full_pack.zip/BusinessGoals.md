# BusinessGoals.md
### Modernization Target: Legacy UFunc CAD → .NET Backend + React Frontend

## Primary Business Goals

- Reduce reliance on rare legacy UFunc/NX CAD development skills.
- Increase maintainability by moving to widely supported technologies (.NET + React).
- Improve user experience by replacing text-based UI with modern web forms.
- Decrease onboarding time for new developers and CAD operators.
- Enable modular feature delivery and reduce time to market for enhancements.
- Support AWS deployment and cloud-readiness (future scaling capability).

## Non-Functional Business Goals

- System stability during phased migration.
- Backward compatibility for critical CAD workflows.
- Improved observability, logging, and troubleshooting.
- Basic internal authentication to control access to UI and APIs.

## Constraints

- CAD operations must remain accurate and traceable.
- No disruption to existing NX/UG workflow during modernization stages.
