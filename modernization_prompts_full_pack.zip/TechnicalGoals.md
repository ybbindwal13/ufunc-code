# TechnicalGoals.md
### Modernization Target: Legacy UFunc CAD → .NET Backend & React 19 (AWS Deployment)

## Technical Modernization Goals

### Backend (.NET)
- Use .NET (ASP.NET Core) with Clean Architecture principles.
- Implement Minimal APIs with proper DTOs.
- Modularize CAD logic into services (Plate, BoltCircle, EdgeOperations, Reporting, BatchJobs).
- Abstract NX/UG API calls behind adapters or integration interfaces.
- Introduce unit tests and integration tests for critical logic.

### Frontend (React 19 + Vite + TypeScript)
- Use functional components and hooks.
- Implement a React Router-based structure with pages for each CAD function.
- Build form-based UIs for CAD parameters with validation.
- Integrate with backend APIs using Fetch or Axios.

### Deployment (AWS)
- Containerize backend and frontend separately.
- Deploy backend to AWS ECS or AWS Fargate.
- Deploy frontend using AWS Amplify or S3 + CloudFront.
- Store configuration securely using AWS Systems Manager Parameter Store.
- Use CloudWatch for logging and basic monitoring.

### Authentication
- Implement internal basic authentication for initial rollout.
- Store credentials securely (not in code).
- Add middleware for authentication on API endpoints.

### Testing & Quality
- Backend: xUnit + FluentAssertions.
- Frontend: Jest + React Testing Library.
- E2E: Playwright or Cypress.

## Constraints
- CAD/NX operations may require local environment for specific modules.
- Phased migration must prevent feature regression during rollout.
