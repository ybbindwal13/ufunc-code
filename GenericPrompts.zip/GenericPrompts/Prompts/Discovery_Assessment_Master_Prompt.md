# Discovery & Assessment — Master Prompt (Works with or without documentation)

You are an **expert software modernization assistant**. Perform the **Discovery & Assessment** phase for a legacy application using the inputs and requirements below. This prompt is designed to work whether the documents are complete, incomplete, or missing.

---

## Inputs
- **You have all access to create files and folders**
- **Check if folder alreadys exist . if yes, use the existing folder**
- **Source Code:** `C:\Repository\HotelBuddy-LegacyCode\HotelBooking`
- **Business Goals (Optional):** `C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\Prompts\Goals\BusinessGoals.md`
- **Output Folder:** `C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\1_Discovery_Documents`

> If Business Goals are available, align discovery findings with business objectives.

---

## Golden Rules (quality, safety, privacy)
1. **Do not execute code** unless explicitly asked to do so. Use static analysis first.
2. **Do not send any code or data to external services.** Treat everything as confidential.
3. **Protect personal and sensitive data.** Redact secrets and personal identifiers in outputs.
4. **Use clear, simple English.** Avoid abbreviations. If you must use one, expand it first time.
5. **Always state confidence and assumptions.** Call out gaps requiring expert review.
6. **Traceability is required.** Link every finding to the file, line, or artifact where you found it.

---

## Decision logic for documentation
- **If documents exist:** Summarize them and validate against the actual source code and configurations.
- **If documents are incomplete:** Merge the documents with code and configuration analysis to fill gaps.
- **If no documents exist:** Build all required understanding from the source code, configurations, logs, and expert interviews.

Always verify the final picture against **what is deployed** and **how it actually runs** where possible (configs, manifests, service definitions).

---

## Activities (what you must do)

### A. Functional understanding
- Identify High-level functional summary of the project. It describes the problem the system aims to solve, the business goals, and the overall objectives.
- Identify **business capabilities** and **system features**. 
- Describe the main workflows that the application supports. Use **process diagrams or flowcharts** to make these sequences easy to understand in draw.io format.
- Produce a **functional map**: feature → owning module → key files → data touched.
- Identify the **inputs and outputs** of the system. Is the system integrated with any external systems(i.e: Banks, Storage) ?
- Extract **key business rules** and **calculations** from the code.
- Note **manual steps** and **workarounds** used by users or support teams.

### B. Architecture (as‑is)
- Provide **high-level Architecture diagram** showing the main components, data flow, and how the system interacts with other applications (e.g., databases, external APIs, and user interfaces)
- Identify the specific languages, frameworks, libraries, and databases used.
- Provide **Context, Container, and Component** views (C4 style, explained in plain words).
- Describe **deployment topology** (servers, containers, clusters, regions, networks).
- List **runtime configurations** (environment variables, app settings, feature flags).
- Identify **technology stack** versions and **platform constraints**.

### C. Module and Component Inventory
- Identify the List of all individual **components**, including their purpose, responsibilities, and their version number or technology stack
- Identify the List of all **modules / services / layers** and their responsibilities.
- Understand **how modules interact** (calls, events, shared databases, libraries).
- Note shared utilities and cross‑cutting components (logging, authentication, authorization) and the related packages or frameworks used.

### D. Workflow and process documentation
- Describe **end‑to‑end flows** for the top business journeys (for example, “Create Order”, “Approve Invoice”).
- For each flow, capture steps, inputs, outputs, and failure points.
- Identify **data lineage** (where data originates, how it transforms, and where it is stored).
- Determine whether any communication services are implemented (such as email delivery, one-time password (OTP), or SMS messaging solutions).

### E. Dependency and integration inventory
- Databases (type, connection strings, schemas, critical tables, stored procedures, triggers, indexes).
- External systems (APIs, message queues, file exchanges, shared drives, third‑party SDKs).
- Schedulers and batch jobs (cron, Quartz, Hangfire, Windows Task Scheduler, Kubernetes CronJobs, SQL Agent jobs).
- Configured endpoints, timeouts, retries, and error handling behavior.

### F. Environment and operations
- How is it built and deployed today (manual steps, scripts, pipelines).
- Where does it run (on premises, cloud). Include web servers, app servers, background workers.
- Logging and monitoring status (what exists, gaps, retention).
- Backups and restore procedures (databases, files, configurations).
- Access control and identity (who can deploy, who can access production).

### G. Technical Debts
- Performance risks (expensive queries, synchronous calls in hot paths, N+1 query patterns).
- Reliability risks (single points of failure, no retries, shared mutable state).
- Scalability risks (tight coupling, shared database across many modules, no caching).
- Maintainability risks (spaghetti code, large God‑classes, dead or unreadable code, cyclic dependencies, duplicate logic).
- Look for Security risks: hardcoded secrets, outdated libraries with known security flaws, weak cryptography, missing input validation or poor authentication/authorization practices, SQL Injection risks.
- Licensing and third‑party risks: unclear open‑source licenses, unsupported libraries.
- Identify Process Debt: lack of automated testing, manual deployment processes, no version control

### H. To be Validated
- Create a list of **open questions** for architects, domain experts, developers, operations, and support.
- Mark **assumptions** and **unknowns**. Suggest how to confirm them.
- Propose a **short validation plan** (interviews, read‑throughs, demo sessions).

---

## Deliverables (what you must produce in the output folder)

***Create a single HTML5 document that runs in browser with all menus below.
Place it under `C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\1_Discovery_Documents`. Use exact names and structures.***

**HTML5 Document Title: 'DISCOVERY AND ASSESSMENT'**

### A. Orientation
- `README_Discovery.md` — brief guide to all deliverables and how to read them.

### 1. Functional Summary (for non‑technical readers)
- Include the contents from the **Functional understanding** activity.

### 2. Architecture views (as‑is) This section sets for Business, development and support teams.
 - Include the contents derived from **Architecture (as‑is)** activity.
 - Include `Container_Diagram` as a pictorial representation to capture the containers, runtimes, data stores, integrations. Save it 
 - Include `Component_Diagram` as a pictorial representation to define the main components and their relationships. 
 - Include `Deployment_Topology.drawio` (optional) — network, servers, clusters, regions.

### 3. Functional and module mapping
 - Clicking on this menu should give me a tabular data with the following information
 — sheet per domain area with columns: Feature, Module, Key Files, Data Entities, Notes.
 — columns: Module/Service, Responsibility, Key Repositories/Paths, Interfaces, Owners.

### 4. Workflows and data lineage
- Include the Data Flow Diagram (DFD): A high-level DFD can complement the process flow by showing how data moves between the system, its components, and external entities.
- `Workflow_Main_Flows` — Diagram for top 3–5 business flows.
- `Data_Lineage.mmd` — drawio or PlantUML diagrams showing data movement.

### 5. Dependencies and integrations
- Include the contents derived from **Dependency and integration inventory** activity.
- `Dependency_Inventory` - Tabular structure for Databases, APIs, Files, Message Queues, Schedulers, Libraries.
- `Integration_Contracts` — list of interfaces, protocol, authentication, data models, error codes.
- `Config_Inventory` — environment variables, app settings, connection strings (redact secrets).

### 6. Database understanding
- Include a picture or draw.io file to represent text‑based entity‑relationship diagram
- list schemas and main tables with purpose.
- ORM and data access approaches

### 7. Technical health
- Include the knowledge gained from the **Technical Debts** activity.

### 8. Gaps and validation
- Missing documents, Unknowns, Assumptions, Validation Plan, Target Owner.
- list of questions grouped by role (business, architecture, development, operations).

### 9. Traceability and summary
- Business Feature → Module → Interfaces → Data → Risks → Tests (if any).
- summary counts (modules found, integrations, databases, risks by level, open questions).

---
> SAVE ALL THE DRAW.IO FILES OR DIAGRAMS CREATED SEPERATELY IN THE SAME OUTPUT FOLDER.
**Make sure all the sections in the generated HTML5 document has appropriate content**

## Evidence and traceability requirements
- For every finding, record **where it came from** (file path, line range, document name, configuration key).
- When a fact is uncertain, mark it as **assumption** with a confidence level (high, medium, low).
- Prefer **links and anchors** within the outputs to help reviewers navigate.

---

## Hints for extracting information (static analysis first)
- **Languages and frameworks:** list versions and build tools.
- **Configuration files:** `appsettings*.json`, `web.config`, `.properties`, `.yml`, `.env`, `Dockerfile`, `docker-compose.yml`, `helm`, Kubernetes manifests.
- **Entry points:** web controllers, service endpoints, message handlers, scheduled jobs.
- **Database access:** ORM mappings, SQL scripts, stored procedures, migration files.
- **Integrations:** HTTP clients, SDK initializations, message producers/consumers, file I/O paths.
- **Security:** authentication, authorization, encryption, secret storage, certificate use.
- **Logging:** log frameworks, log levels, correlation IDs, audit trails.
- **Packaging & deployment:** CI/CD scripts, build pipelines, release notes, runbooks.

---

## Completion checklist (you must meet all of these)
- Functional Map complete and reviewed for accuracy.
- Module Catalog complete with responsibilities.
- Dependency Inventory covers databases, APIs, files, queues, and schedulers.
- Main workflows diagrammed and validated.
- Architecture views (context, container, component) created.
- Database understanding documented (schema and entity relationships).
- Technical Health Report lists top risks with suggested mitigations.
- Gap Report and Questions for Experts prepared.
- Traceability Matrix connects features to modules, data, and risks.
- Executive Summary created for business stakeholders.
- Discovery Status JSON written with key counts and confidence.

---

## Human review points (guardrails)
- An architect or expert must **review** the Executive Summary, Architecture Views, and Technical Health Report.
- A database administrator must **review** Database Schema and Entity Relationship outputs.
- A security lead must **review** risks and any mention of secrets or vulnerabilities.
- Business users must **validate** the Functional Map and top workflows.

---

## Output formatting
- Use clear headings, tables, lists, and short paragraphs.
- Prefer **Draw.io** formats and embed them in web page. It should also be downloadable.
- If diagrams are not achievable, use tabluar format.
---

## Final action
When you start, print a short banner stating which case you detected:
- “Documents present and will be validated,” or
- “Documents incomplete, merging with code analysis,” or
- “No documents, relying on code, configurations, logs, and interviews.”
