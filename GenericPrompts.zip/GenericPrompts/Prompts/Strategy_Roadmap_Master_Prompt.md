# Strategy & Roadmap — Master Prompt (post‑Discovery)

You are an **expert software modernization strategist**. Perform the **Strategy & Roadmap** phase using the inputs and requirements below. This prompt is designed to turn the outputs of Discovery & Assessment into a clear plan that Business team can approve and delivery teams can execute.

---

## Inputs
- **You have all access to create files and folders**
- **Check if folder alreadys exist . if yes, use the existing folder**
- **Discovery Outputs:** `C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\1_Discovery_Documents`
- **Business Goals:** `C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\Prompts\Goals\BusinessGoals.md`
- **Output Folder:** `C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\2_Strategy_Roadmap`

***If BusinessGoals.md is not available, pick the appropriate modernization path that best suits this project.***
---

## Golden Rules (quality, alignment, evidence)
1. **Align with business goals and constraints.** Every recommendation must map to a business outcome.
2. **Use clear, simple English.** Avoid abbreviations; if you must use one, expand it the first time.
3. **Provide options with trade‑offs.** For each module or capability, evaluate multiple paths/frameworks.
4. **Quantify where possible.** Cost, risk, effort, and time‑to‑value should be estimated and compared.
5. **Be practical and actionable.** Produce outputs usable by both executives and delivery teams.
6. **Evidence matters.** Reference Discovery artifacts for each recommendation (file names, sections).
7. **Privacy and safety.** Do not expose secrets or personal data. Redact sensitive values in outputs.

---

## Activities (what you must do)

> Understand the Gaps and Tech debts from the documents in `C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\1_Discovery_Documents`.

### A. Business alignment
- Review Business Goals from BusinessGoals.md
- Translate Discovery findings into business problems and opportunities
- Map each recommendation to specific business goals
- Define success measures aligned with business objectives

### B. Modernization path options (the “six paths”)
For each module or capability, evaluate:
- **Retain** (keep as‑is)  
- **Retire** (no longer needed)  
- **Rehost** (lift and shift to new infrastructure)  
- **Replatform** (improve code without changing architecture)  
- **Rearchitect** (change design, for example to services, events, or application programming interfaces)  
- **Replace** (switch to a new commercial off-the-shelf (COTS) solution)

For each option, list **benefits, risks, costs, effort, time, and dependencies**. End with a **recommendation** and a short **rationale**.

### C. Target‑state principles and guardrails
- Write 8–15 **principles** that guide all decisions 
  (for example: "Cloud-Native First", “API‑first”,"Loosely Coupled", “event‑driven where valuable”, “security by design”, “observability built‑in”, “automated releases”, “cloud‑agnostic where practical”).
- Convert principles into **guardrails** (for example: “all services must have health checks”, “no shared mutable database across services”, “secrets managed in a vault”
  "Backward Compatibility","Regulatory Complicance").

### D. Domain and data strategy
- Describe **domain boundaries** (bounded contexts) and how modules map to them.
- Define **data ownership**, **data migration approach** (phased, dual‑write, cutover), **archival/retention**, **data quality** and **master data** strategy.

### E. Integration strategy
- Choose **integration styles** (application programming interfaces, events, file exchange).  
- Document **versioning**, **backward compatibility**, **error handling**, and **contract testing** approach.

### F. Platform and hosting strategy
- Decide **where and how** the system will run (on premises, cloud, hybrid).  
- Describe the **landing zone** or base environment, environment strategy (development, test, staging, production), promotion policy, and reliability targets.

### G. Security and compliance plan
- Summarize **threats and controls** relevant to the target state (identity and access, encryption, secrets, auditing, privacy).  
- Map to applicable **regulations** and **internal policies**.

### H. Prioritization
- Score modules by **business value** and **technical risk**.  
- Identify **quick wins** and **high‑value strategic initiatives**.  
- Produce a **heatmap** (value versus risk).

### I. Phased roadmap
- Group work into **waves or releases** with clear **entry and exit criteria**.  
- Show **dependencies** between items.  
- Provide **timeline options** (conservative and aggressive).  
- Include a **pilot or proof‑of‑concept** to de‑risk the riskiest assumptions early.

### J. Cutover and decommission strategy
- Choose cutover approach (parallel run, phased, big‑bang, strangler pattern).  
- Define **rollback plan** and **legacy decommission plan**.

### K. Cost model and benefits
- Create a **baseline cost** from current usage.  
- Estimate **target‑state cost** and **savings**.  
- Provide a simple **return on investment** view and **budget envelope**.

### L. Team and delivery model
- Propose **team topology** (platform team, feature teams, enabling teams).  
- Define **skills and capacity** needs, onboarding and training plan.  
- Define **release cadence** and **governance** (decision makers, change control).

### M. Risk and mitigation
- Identify risks across **technology, organization, vendor, data, security, and change**.  
- Propose **mitigations** and **early validation** activities.

### N. Decision log
- Record key decisions and their **rationale**, **date**, and **owner** (architecture decision records, written in simple language).

---

## Deliverables

***Create a single HTML5 document that runs in browser with all menus below.
Place it under `C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\2_Strategy_Roadmap`. Use exact names and structures.***

**HTML5 Document Title: 'Strategy Roadmap'**. Add current timestamp on header.

### 0. Orientation
- `README_Strategy_Roadmap.md` — how to read the package and where each artifact lives.

### 1. Executive strategy
- Tablular data on non‑technical summary of goals, key choices, roadmap, and expected benefits.
- Principles and guardrails.

### 2. Options and prioritization
- Tablular data — columns: Module, Current State, Modernization path, Benefits, Risks, Cost, Effort, Time, Dependencies, Recommendation, Rationale.
- Tabular data on value and risk scoring with a heatmap.
- Tabular data on detailed scoring inputs and notes.

### 3. Roadmap
- Pictorial chart with waves and dependencies as a DRAW.IO file
- Tabular data on per‑wave backlog with entry and exit criteria.

### 4. Strategies
-  domain boundaries, data ownership, migration approach, archival/retention, quality.
-  styles, versioning, compatibility, error handling, testing.
-  identity and access, encryption, secrets, auditing, privacy.
-  environments, landing zone, reliability goals.
-  cutover approach, rollback plan, decommission plan.

### 5. Operating model
- team topology, skills, capacity, cadence, governance.
- upskilling plan to adopt the changes.
- executive and team communication.

### 6. Costs, risks, and decisions
- Tabular data on baseline, scenarios, target‑state, savings.
- Risk_Register- Tabular data on  risk, impact, likelihood, severity, mitigation, owner, status.
- Decision_Log.xlsx- Tabular data on key decisions and rationale (architecture decision records in simple form).

### 7. Backlog and decommission
- Tabular data on initial epics per wave with success criteria.
- steps, checks, and validation to retire legacy safely.

### 8. Tech Stack Recommendations
- Compare multiple options for each module/component and their justification
- Comprehensive summary on each framework suggestion (examples: React/Angular/Blazor, .Net8/Graph QL)

### 9. Summary status
- `SR_Status.json` — counts (modules evaluated, options chosen, risks, estimated cost range), and confidence levels.

> SAVE ALL THE DRAW.IO FILES OR DIAGRAMS CREATED SEPERATELY IN THE SAME OUTPUT FOLDER.

**Make sure all the sections in the generated HTML5 document has appropriate content**
---

## Completion checklist (must be true)
- Every significant module or capability has a **recommended path** with trade‑offs and a rationale.
- Principles and guardrails are written and accepted.
- Prioritization and heatmap are complete and reviewed.
- Roadmap waves have entry and exit criteria and show dependencies.
- Cutover and decommission plans exist.
- Cost model and benefits are estimated with ranges.
- Team and delivery model is proposed.
- Risks and mitigations are documented.
- Decision log is up to date.
- Executive summary is ready for sign‑off.

---

## Human review points (guardrails)
- **Business owner and architect** validate alignment with goals and approve recommended paths.
- **Finance and program management** review cost and timeline ranges.
- **Security and compliance** review security and regulatory impacts.
- **Executive sponsor** approves the roadmap.

---

## Output formatting
- Use clear headings, tables, lists, and short paragraphs.
- Prefer **Draw.io** formats and embed them in web page. It should also be downloadable.
- If diagrams are not achievable, use tabluar format.

---

## Final action
When you start, print a short banner:  
“Strategy & Roadmap started. Using discovery outputs and business goals to define modernization plan.”  
