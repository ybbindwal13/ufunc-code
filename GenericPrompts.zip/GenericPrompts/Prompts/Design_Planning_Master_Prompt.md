# Design & Planning — Master Prompt

You are an **expert modernization architect**.  
Your task is to perform the **Design & Planning phase** for a legacy application modernization initiative.

---

## Inputs
- **You have all access to create files and folders**
- **Check if folder alreadys exist . if yes, use the existing folder**
- **Legacy Source Code:** `C:\Repository\HotelBuddy-LegacyCode\HotelBooking`
- **Discovery Outputs:** `C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\1_Discovery_Documents`
- **Strategy & Roadmap Outputs:** `C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\2_Strategy_Roadmap`
- **Technical Goals:** `C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\Prompts\Goals\TechnicalGoals.md`
- **Output Folder:** `C:\Repository\HotelBuddy-LegacyCode\3_Design_Planning`

***If TechnicalGoals.md is not present, use the recommended tech stack from `C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\2_Strategy_Roadmap\Strategy_Roadmap.html`.***

## Golden Rules
1. **Follow approved strategy.** All design choices must align with principles, guardrails, and roadmap from Strategy & Roadmap.
2. **Business alignment first.** Every design must support business goals and modernization objectives.
3. **Keep it simple.** Use clear English, avoid abbreviations unless explained.
4. **Design for change.** Make it modular, testable, observable, secure, and resilient.
5. **Evidence-based.** Link each design artifact to Discovery and Strategy findings.

---

## Activities (what you must do)

### A. Target Architecture (As-Is → To-Be)
- Create **Context, Container, Component, and Deployment views** (C4 model).
- Define how legacy modules map to new services/components.
- Include **technology stack choices** and rationale.
- Document **hosting model** (cloud, hybrid, on-premises).
- Plan on how endpoints can be mapped and UI modules can be mapped.

### B. Integration Design
- Define RESTFUL APIs, events, and messaging.
- Document contracts (request/response schemas, events, error handling).
- Define versioning and backward compatibility approach.
- Specify adapters for legacy systems during transition.

### C. Data Design & Migration
- Define **data model for new system**.
- Plan **data migration strategy** (dual write, cutover, ETL, archival).
- Include data governance, retention, quality, and privacy rules.
- Create **ER diagrams** and **migration mapping tables**.

### D. Security & Compliance Design
- Apply **principles from Strategy & Roadmap** (identity, encryption, secrets).
- Document authentication/authorization model (roles, claims, RBAC/ABAC).
- Include logging, audit, and monitoring requirements.
- Align with compliance requirements (e.g., GDPR, HIPAA).

### E. Non-Functional Requirements (NFRs)
- Define performance SLAs (latency, throughput).
- Availability & DR (RPO, RTO).
- Scalability and elasticity.
- Observability (metrics, logs, traces, health checks).
- Operability (deployment, rollback, blue/green, canary).
- Version control practices (branching strategy, commit messages, pull requests).

### F. Transition & Coexistence
- Define how new components will **coexist with legacy** during migration.
- Use strangler pattern where possible.
- Plan for feature toggles and staged rollout.

### G. Tooling & Standards
- Document coding standards, testing strategy, CI/CD pipeline design.
- Define reusable templates (infrastructure as code, API guidelines, logging format).
- Suggest static code analysis/linters tools and extensions to integrate in IDE.
- Guidelines for writing secure code (input validation, avoiding hardcoded secrets).
- Use of design patterns and architectural principles (such as SOLID, DRY, KISS).

---

## Deliverables 
***Create a single HTML5 document that runs in browser with all menus below.
Place it under `C:\Repository\HotelBuddy-LegacyCode\3_Design_Planning`. Use exact names and structures.***

**HTML5 Document Title: 'Design Planning'**. Add current timestamp on header.

### 0. Orientation
- `README_Design_Planning.md` — overview of contents.

### 1. Architecture & Design
- Comprehensive summary on the target architecture and system design based on the technical goals defined.
- `Target_Architecture_Context.drawio` - Pictorial representation of target design.
- `Target_Architecture_Components.drawio` - Detailed overview of the Components involved and their changes to adopt new design.
-  rationale for stack choices.

### 2. Integration
- List of all API endpoints and their summary
- `API_Specifications.yaml` — OpenAPI or AsyncAPI specs.
- `Integration_Contracts` — Tabular data on services, APIs, events, schemas.
- Error handling strategies (examples: circuit breaker, retry pattern)
- Dependency Mapping: Create a clear map of all internal and external dependencies that will change as part of this process.
- `Target_Deployment_Topology.drawio` - Map how the components look in the deployment topology.

### 3. Data
- Summary of Data model changes.
- `Target_Data_Model_ER.drawio` - Entity relationship diagram for target system.
- Elaborate the Data migration strategy. This could be a "strangler fig" pattern, a complete rewrite, or a phased migration.
- Data_Mapping_Tables — Tabular data on source → target mapping.

### 4. Security & Compliance
- `Security_Model` — Identity, access control,RBAC, Encryption.
- `Compliance_Checklist` — controls vs. regulations.

### 5. NFRs
- Non-functional requirements to be implemented.
- Disaster Recovery Plan.
- Scalability Plan for the new system.

### 6. Transition & Coexistence
- Phased Rollout Plan: Document a detailed project timeline, breaking the modernization into manageable phases with clear milestones and deliverables.
- Testing and Validation Plan: Outline the strategy for testing the new application, including unit, integration, and user acceptance testing (UAT). This section should also detail how the new system will be validated against the legacy one to ensure functional parity.
- Explore Feature_Toggle_Strategy by prioritizing the modules/features.

### 7. Tooling & Standards
- Document the findings from 'Tooling & Standards' activity.
- `CI_CD_Pipeline_Design` - document the key pipelines needed to continously deliver.

### 8. Risks & Decisions

 - This section documents all identified risks and key decisions made during the Design & Planning phase. It ensures transparency, traceability, and proactive risk management.

- **Content:** Tabular record of risks, including:
  - Risk ID
  - Description
  - Impact (High/Medium/Low)
  - Likelihood (High/Medium/Low)
  - Mitigation Strategy
  - Owner
  - Status (Open/Closed)
  - Date Identified

#### Decision Log
- **Content:** Tabular record of major decisions, including:
  - Decision ID
  - Description
  - Rationale
  - Alternatives considered
  - Impact on design/architecture
  - Owner
  - Date
  - Status (Approved/Pending/Rejected)

> Both tables must be kept up to date throughout the project and reviewed at each milestone.

### 9. Summary
- `DP_Status.json` — design completion status, confidence, risks, open issues.

> SAVE ALL THE DRAW.IO FILES OR DIAGRAMS CREATED SEPERATELY IN THE SAME OUTPUT FOLDER.
**Make sure all the sections in the generated HTML5 document has appropriate content**

## Completion Checklist
- Target architecture views complete and aligned with strategy.
- Integration and API contracts documented.
- Data migration approach and mapping tables prepared.
- Security and compliance requirements addressed.
- NFRs clearly defined and measurable.
- Transition and coexistence plan in place.
- Tooling and standards documented.
- Risks and decisions captured.
- Executive summary present.

---

## Human Review Guardrails
- Architects validate architecture views and technology choices.
- DBAs validate data migration design.
- Security team validates security model.
- Operations team validates deployment design and NFRs.
- Business owners validate that designs support roadmap goals.

---

## Final Action
At the start, print a banner:  
“Design & Planning started. Using Discovery and Strategy outputs to create target design and migration plan.”  
Then generate all deliverables into `C:\Repository\HotelBuddy-LegacyCode\3_Design_Planning`.
