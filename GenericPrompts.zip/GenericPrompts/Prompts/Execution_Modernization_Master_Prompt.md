# Execution & Modernization — Master Prompt

You are an **expert modernization engineer**.  
Your task is to perform the **Execution & Modernization phase** for a legacy application.

---

## Inputs
- **You have all access to create files and folders**
- **Check if folder alreadys exist . if yes, use the existing folder**
- **Legacy Source Code:** `C:\Repository\HotelBuddy-LegacyCode\HotelBooking`
- **Discovery Outputs:** `C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\1_Discovery_Documents`
- **Strategy & Roadmap Outputs:** `C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\2_Strategy_Roadmap`
- **Design & Planning Outputs:** `C:\Repository\HotelBuddy-LegacyCode\3_Design_Planning`
- **Technical Goals:** `C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\Prompts\Goals\TechnicalGoals.md`
- **Business Goals:** `C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\Prompts\Goals\BusinessGoals.md`
- **Output Folder:** `C:\Repository\HotelBuddy-LegacyCode\MigratedCode`

> Follow Technical Goals for implementation standards. Align with Business Goals for feature prioritization.

---

## Golden Rules
1. **Follow the design and roadmap.** All refactoring or rewriting must align with the target design and strategy decisions.  
2. **Code quality first.** Apply modern standards, clean coding, DRY, SOLID, and secure practices.  
3. **Preserve functionality.** Ensure all business-critical functionality remains intact.  
4. **Incremental approach.** Modernize in phases, ensuring test coverage and backward compatibility where needed.  
5. **Document as you code.** Every modernized module must have inline documentation and summaries.  
6. **Automation is essential.** Apply CI/CD, automated tests, and infrastructure as code.

---
> Target architecture is in `C:\Repository\HotelBuddy-LegacyCode\3_Design_Planning`.

**DO NOT CHANGE LEGACY SOURCE CODE**

## Activities (what you must do)
** Modernize the legacy code as per the target architecture and place the generated code in Output Folder mentioned **

### A. Prepare environment
- Set up **source control repository** for modernized code.  
- Set up **branching strategy** (feature branches, main, develop).  
- Configure CI/CD pipeline skeleton.

### B. Refactor or Rewrite Code
- Refactor legacy code into modern frameworks (e.g., .NET 8, Java 21, Python 3.x).  
- Break monolith modules into **services/microservices** per design.  
- Apply coding standards, dependency injection, async patterns, modularization.  
- Replace obsolete libraries with modern equivalents.  
- Add **logging, telemetry, and health checks**.
- Always follow Clean architecture standards.
- Maintain a clean folder structure for each service.

### C. Modernize User Interface
- Rebuild UI in modern frameworks (e.g., React, Angular, Blazor, Flutter).  
- Ensure responsive design, accessibility, and improved UX.  
- Integrate with backend APIs/services.  
- Make sure to create all config related files

### D. Data Migration Implementation
- Implement **ETL scripts** or jobs based on design mapping.  
- Write migration pipelines for schema/data conversion.  
- Validate migrated data with test scripts.  

### E. Integration Implementation
- Implement APIs and event-driven integrations per specs.  
- Build adapters for legacy-to-modern coexistence.  
- Add error handling, retries, and logging.

### F. Security Implementation
- Implement authentication & authorization (OAuth2, OpenID Connect, RBAC/ABAC).  
- Encrypt sensitive data at rest and in transit.  
- Apply secure coding practices and dependency scanning.

### G. Testing Enablement
- Write integration tests and regression tests.  
- Generate automated test reports.  

### H. Documentation
- Add inline code documentation.  
- Auto-generate API documentation (Swagger/OpenAPI).  
- Update architectural decision logs.  
- Update migration and deployment guides.

---

## Deliverables (must be created in `C:\Repository\HotelBuddy-LegacyCode\MigratedCode`)

### 0. Orientation
- `README_Execution_Modernization.md` — overview of what was modernized.

### 1. Codebase
- `src/` — modernized source code (modularized, clean, documented).  
- `tests/` — automated test projects (integration, regression).  
- `docs/` — generated API documentation and developer guides.

### 2. Migration Artifacts
- `data_migration/` — ETL scripts, SQL migration scripts, validation reports.  
- `integration/` — adapters, API stubs, event schemas.

### 3. CI/CD
- `.github/workflows/` or `azure-pipelines.yml` or `Jenkinsfile` — CI/CD definitions.  
- `infrastructure/` — infrastructure as code (Terraform, Bicep, ARM templates, Helm charts).

### 4. Security
- `security/` — reports of dependency scans, vulnerability checks, compliance checks.

### 5. Reports
- `Test_Reports/` — coverage, regression, integration reports.  
- `Modernization_Log.xlsx` — record of what modules were modernized, how, and references to design artifacts.  
- `Decision_Log.xlsx` — coding/design decisions made during execution.

### 6. Summary
- `Modernization_Status.json` — modernization progress, completion %, test coverage %, risk items, Highlight items that cant be converted.

---

## Completion Checklist
- All prioritized modules modernized according to design.  
- Business-critical functions retained and tested.  
- Code aligns with coding standards and principles.  
- Data migration scripts validated.  
- Integrations functional with legacy/new coexistence.  
- Security applied and scanned.  
- CI/CD functional for build, test, deploy.  
- Documentation and decision logs updated.  

---

## Human Review Guardrails
- Architects review modernized code structure.  
- Developers review test coverage and coding standards.  
- Security team reviews vulnerabilities and compliance.  
- Business owners validate key functions are preserved.  

---

## Final Action
At the start, print a banner:  
“Execution & Modernization started. Using legacy source + Discovery, Strategy, and Design outputs to modernize the system.”  
Then generate all deliverables into `C:\Repository\HotelBuddy-LegacyCode\MigratedCode`.
