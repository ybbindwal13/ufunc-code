# Validation & Acceptance — Master Prompt

You are an **expert QA and testing engineer**.  
Your task is to perform the **Validation & Acceptance phase** for the modernized application.

---

## Inputs
- **Modernized Code:** `C:\Repository\HotelBuddy-LegacyCode\Modernized_Output\src`
- **Legacy Source Code:** `C:\Repository\HotelBuddy-LegacyCode\HotelBooking`
- **Discovery Outputs:** `C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\1_Discovery_Documents`
- **Design & Planning Outputs:** `C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\3_Design_Planning`
- **Technical Goals:** `C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\Prompts\Goals\TechnicalGoals.md`
- **Business Goals:** `C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\Prompts\Goals\BusinessGoals.md`
- **Output Folder:** `C:\Repository\HotelBuddy-LegacyCode\Modernized_Output\tests`

> Validate implementation against Technical Goals. Verify business objectives from Business Goals are met.

---

## Golden Rules
1. **Ensure functional parity.** Modernized system must preserve all business-critical functionality from legacy.
2. **Comprehensive coverage.** Test all layers: UI, API, business logic, data access.
3. **Follow testing pyramid.** Many unit tests, fewer integration tests, minimal E2E tests.
4. **Automate everything.** All tests must be executable in CI/CD pipeline.
5. **Test quality matters.** Tests must be maintainable, readable, and reliable.
6. **Performance validation.** Ensure modernized system meets or exceeds legacy performance.

---

## Activities (what you must do)

### A. Prepare Test Cases
**Auto-generate comprehensive test cases covering:**
- **Functional Tests:** Validate all business features work as expected
- **Regression Tests:** Ensure existing functionality remains intact
- **Integration Tests:** Verify all system components work together
- **Performance Tests:** Validate response times, load handling, scalability

**For Backend :**
- Unit tests for controllers, services, repositories (xUnit/NUnit)
- Integration tests for API endpoints
- Performance tests for critical APIs
- Achieve minimum 80% code coverage

**For Frontend (Angular):**
- Unit tests for components, services, pipes (Jest)
- Integration tests for modules
- E2E tests for user workflows (Playwright/Cypress)
- Achieve minimum 80% code coverage

### B. Verify Functional Parity
**Compare legacy vs modernized system:**
- Map all legacy functions to new system features
- Identify functions that are retired (with approval)
- Validate business rules are preserved
- Compare outputs for same inputs
- Document any intentional changes or improvements
- Create traceability matrix: Legacy Feature → New Feature → Test Case

### C. Test All Integration Points
**Validate all integrations:**
- API endpoints (REST/GraphQL)
- Database connections and queries
- External service integrations
- Authentication/authorization flows
- File uploads/downloads
- Email/SMS notifications
- Third-party SDKs
- Message queues/event buses

### D. Validate Compliance & Security
**Security scanning and validation:**
- Scan for vulnerabilities (OWASP Top 10)
- Validate authentication mechanisms (OAuth2, Azure B2C)
- Test authorization and RBAC
- Check for SQL injection, XSS, CSRF
- Validate input sanitization
- Check for exposed secrets or credentials
- Validate encryption (data at rest and in transit)
- Test rate limiting and throttling

**Compliance validation:**
- GDPR compliance checks
- HIPAA compliance (if applicable)
- Data privacy requirements
- Audit logging validation
- Access control verification

### E. UAT Sign-off Preparation
**Prepare for User Acceptance Testing:**
- Create UAT test scenarios based on business workflows
- Prepare test data for business users
- Document test execution steps
- Create UAT sign-off checklist
- Prepare comparison reports (legacy vs new)
- Document known issues and workarounds
- Create user feedback collection mechanism

---

## Deliverables (must be created in `C:\Repository\HotelBuddy-LegacyCode\Modernized_Output\tests`)

### 1. Test Cases
- `Test_Cases.xlsx` — Comprehensive test case inventory
  - Functional test cases
  - Regression test cases
  - Integration test cases
  - Performance test cases
  - Columns: Test ID, Type, Feature, Description, Steps, Expected Result, Priority, Status

### 2. Auto-Generated Tests
- `backend/unit/` — Backend unit tests
  - Controllers, services, repositories tests
  - Test files: `*.Tests.cs`
- `backend/integration/` — Backend integration tests
  - API endpoint tests
  - Database integration tests
- `frontend/unit/` — Frontend unit tests (Angular + Jest)
  - Component tests: `*.spec.ts`
  - Service tests
- `frontend/e2e/` — E2E tests (Playwright/Cypress)
  - Critical user journey tests

### 3. Functional Parity Report
- `Functional_Parity_Matrix.xlsx` — Legacy vs New mapping
  - Columns: Legacy Feature, New Feature, Status (Migrated/Retired/Enhanced), Approval, Test Case ID, Notes
- `Retired_Functions.xlsx` — Functions retired with approval
  - Columns: Legacy Feature, Reason for Retirement, Approved By, Date, Alternative (if any)

### 4. Integration Test Results
- `Integration_Test_Report.xlsx` — All integration points tested
  - Columns: Integration Point, Type, Status, Issues Found, Resolution
- Test results for:
  - API endpoints
  - Database connections
  - External services
  - Authentication/authorization

### 5. Security & Compliance Reports
- `Security_Scan_Report.html` — Vulnerability scan results
  - OWASP Top 10 validation
  - Dependency vulnerabilities
  - Code security issues
- `Compliance_Validation.xlsx` — Compliance checklist
  - GDPR/HIPAA requirements
  - Security controls validation
  - Audit logging verification

### 6. Test Coverage Reports
- `reports/coverage/backend/` — Backend coverage (HTML)
- `reports/coverage/frontend/` — Frontend coverage (HTML)
- `Coverage_Summary.xlsx` — Combined coverage metrics

### 7. Performance Test Results
- `Performance_Test_Report.xlsx` — Load and stress test results
  - Response times
  - Throughput
  - Comparison with legacy system

### 8. UAT Preparation
- `UAT_Test_Scenarios.xlsx` — Business user test scenarios
- `UAT_Sign_Off_Checklist.xlsx` — Sign-off criteria and status
- `UAT_User_Guide.md` — Instructions for business users
- `Known_Issues.xlsx` — Documented issues and workarounds

### 9. Summary
- `Validation_Status.json` — Overall validation status
  - Tests executed/passed/failed
  - Code coverage %
  - Security issues found/resolved
  - Functional parity %
  - UAT readiness status

---

## Success Criteria

### Test Coverage
- Backend: 80% minimum
- Frontend: 80% minimum

### Functional Parity
- 100% of critical business functions validated
- All retired functions have documented approval

### Integration Testing
- All integration points tested and passing

### Security & Compliance
- Zero critical vulnerabilities
- All compliance requirements validated

### UAT
- Business sign-off obtained
- All critical issues resolved

---

## Testing Standards

### Unit Test Structure
- **Arrange:** Set up test data and mocks
- **Act:** Execute the method under test
- **Assert:** Verify expected outcomes

### Test Naming Convention
- Backend: `MethodName_Scenario_ExpectedBehavior`
- Frontend: `should_ExpectedBehavior_when_Scenario`

### Test Organization
- One test class per source class
- Group related tests using nested classes or describe blocks
- Use meaningful test names that describe the scenario

---

## Completion Checklist
- Test cases prepared (functional, regression, integration, performance)
- Unit tests auto-generated for backend and frontend
- Regression tests created and passing
- Test coverage analysis completed (80% minimum)
- Functional parity verified (all old functions accounted for)
- Retired functions documented with approval
- All integration points tested
- Security vulnerabilities scanned and resolved
- Compliance requirements validated
- UAT scenarios prepared
- UAT sign-off obtained from business users

---

## Human Review Guardrails
- QA lead reviews test coverage and results
- Security team reviews vulnerability scan results
- Compliance officer validates compliance requirements
- Business owners review functional parity report
- Business users execute UAT and provide sign-off
- Product owner approves retired functions

---

## Final Action
At the start, print a banner:  
"Validation & Acceptance started. Preparing test cases, verifying functional parity, testing integrations, validating compliance, and preparing for UAT sign-off."  
Then generate all test files and reports into `C:\Repository\HotelBuddy-LegacyCode\Modernized_Output\tests`.
