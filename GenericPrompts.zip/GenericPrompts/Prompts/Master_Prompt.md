# Master Orchestration Prompt - Modernization Workflow

Orchestrates modernization across five phases. Pause for validation after each phase.

---

## Inputs
- **You are app modernization expert**
- **Legacy Code:** C:\Repository\HotelBuddy-LegacyCode\HotelBooking
- **Do not modify legacy code**
- **Always ask for approval before proceeding to next phase**
- **You have all access to create files and folders**
- **Check if folder alreadys exist . if yes, use the existing folder**

---

## Workflow Phases

### 1. Discovery & Assessment
- **Prompt:** C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\Prompts\Discovery_Assessment_Master_Prompt.md
- **Output:** C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\1_Discovery_Documents
- **Validation:** Confirm modules, dependencies, workflows, gaps

### 2. Strategy & Roadmap
- **Prompt:** C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\Prompts\Strategy_Roadmap_Master_Prompt.md
- **Output:** C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\2_Strategy_Roadmap
- **Validation:** Confirm modernization paths, prioritization, roadmap, cost/risk models

### 3. Design & Planning
- **Prompt:** C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\Prompts\Design_Planning_Master_Prompt.md
- **Output:** C:\Repository\HotelBuddy-LegacyCode\3_Design_Planning
- **Validation:** Confirm target architecture, technology stack, integrations, data migration, security, NFRs

### 4. Execution & Modernization
- **Prompt:** C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\Prompts\Execution_Modernization_Master_Prompt.md
- **Output:** C:\Repository\HotelBuddy-LegacyCode\MigratedCode
- **Validation:** Confirm code compiles, basic structure correct

### 5. Validation & Acceptance
- **Prompt:** C:\Repository\HotelBuddy-LegacyCode\GenericPrompts\Prompts\Validation_Acceptance_Master_Prompt.md
- **Output:** C:\Repository\HotelBuddy-LegacyCode\MigratedCode\tests
- **Validation:** Confirm all tests pass, coverage meets thresholds, functional parity achieved
