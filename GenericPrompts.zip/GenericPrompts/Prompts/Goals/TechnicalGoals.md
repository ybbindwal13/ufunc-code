### To-Be Architecture - Angular Front end / .Net8 API backend / MS SQL As Database.###

### UI Goals: Angular v20 Application ###
- Implement a Component-Based UI
- Use SCSS for styling
- Create seperate modules for each functionality
- Create appropriate modules and register the components and services inside the module
- make sure to follow the standard folder structure
- Make sure routing is configured

### Backend Goals: .NET 8 Web API with Clean Architecture ###

## Decompose the Monolithic Application: 
- Separate the presentation (views) and business logic (controllers and models) from the existing MVC2 application. 
- The business logic, services, and data access layers should be isolated and refactored into a new .NET 8 Web API project.

## API
- Create RESTful APIs: Design and implement a set of RESTful APIs that the new React front end will consume. 
- Ensure these APIs provide a well-defined, consistent, and versioned contract (for example, /api/v1/users, /api/v1/products)
- Leverage ASP.NET Core’s built-in routing, dependency injection and API controller features.
- Use middlewares for implementing oAuth Authentication,
- Implement API versioning to allow for future changes without breaking existing clients.
- Document the API using the OpenAPI specification and Swagger.

## Architecture: 
- The new backend should follow the principles of Clean Architecture to ensure maintainability, testability, and scalability. This means creating distinct project layers
- Implement Entity Framework Core with CQRS pattern for database queries. Implement proper transaction boundaries.
- Implement Minimal API's for lighter endpoints. Replace Heavy Controllers with Minimal APIs
- Implement async/await patterns
- Implement repository pattern for database access and dependency injection

## Communication
- Implement Azure Communication service for sending mails to end users on their booking
- Analyze pathway to implement One time password capabilities for login

## Security
- Integrate Azure B2C for customer to login with SSO capabilities
- Implement least privelige data access patterns
- Implement ratelimiting middleware on hotel search API's

## Best Practices
- Prefer Records Over Verbose DTOs
- Implement connection pooling with Httpclient, SQL CLient.
- Short Methods and Classes: Aim for concise methods 
- Parameterized Queries: Use parameterized queries when interacting with databases

## Infrastructure and deployment
- API will be deployed to a Azure App service
- UI will have deployed to a Azure Static Web app
- Enable deployment slots in App services