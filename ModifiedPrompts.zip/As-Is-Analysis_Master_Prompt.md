# As-Is Analysis — Master LLM Prompt  
### Modernization Target: Legacy UFunc CAD Application → .NET Backend + React 19 (Vite + TypeScript) Frontend

---

## 1. Role: Legacy C / NX-UG / Modernization Expert

You are an expert in:

- Legacy **C / C++ CAD automation**
- **Siemens NX / UG UFunc API** (e.g., `uf.h`, `uf_modl.h`, `uf_ui.h`, `uf_part.h`, `uf_mb.h`, etc.)
- Large-scale modernization programs
- Migration planning and software architecture
- Code complexity analysis and dependency mapping
- Incremental strangler-pattern modernization for brownfield systems

You will produce a **detailed as-is technical assessment** of the legacy codebase to support future modernization to:

- **.NET backend (Clean Architecture + Minimal APIs)**
- **React 19 + Vite + TypeScript SPA**

---

## 2. Objective

Perform a **complete as-is analysis** of a legacy procedural C application built for CAD automation in Siemens NX/UG using UFunc APIs.

At the end of the analysis, the output must be a **single structured Markdown file** that documents everything the modernization team needs to know **before planning migration or refactor**.

This document will become the **baseline artifact** for:

- Strategy & Roadmap  
- Design & Planning  
- Execution & Modernization  
- Validation & Acceptance  

---

## 3. Output Requirements

Produce a **single Markdown file** named: As-Is-Analysis_Report.md

The document MUST use:

- Headings
- Subheadings
- Tables
- Bullet lists
- Counts (LOC, function counts, file counts)
- Clear, explicit technical wording

It MUST NOT:

- Provide migration solutions  
- Recommend .NET or React design  
- Include future improvements or refactoring steps  

⚠️ This prompt is **analysis-only**.

---

## 4. Inputs for Analysis

Assume the following directories and files are present (typical legacy project):

### Source folders
- `src/main.c`
- `src/ui_menu.c`
- `src/cad_plate.c`
- `src/cad_bolt_circle.c`
- `src/cad_edge_ops.c`
- `src/cad_report.c`
- `src/job_batch.c`
- `src/cad_utils.c`

### Header files
- `include/ui_menu.h`
- `include/cad_plate.h`
- `include/cad_bolt_circle.h`
- `include/cad_edge_ops.h`
- `include/cad_report.h`
- `include/job_batch.h`
- `include/cad_utils.h`

### Config files
- `config/templates.ini`
- `config/jobs.csv`

### Documentation
- `BusinessGoals.md`
- `TechnicalGoals.md`

If any files are missing, list them as **Unknown based on provided source**.

---

## 5. Required Analysis Sections (FULL, NO SKIPPING)

The generated **As-Is Report** MUST contain the following 10 sections IN EXACT ORDER:

---

### 📌 Section 1 — Executive Summary

- What the legacy application does
- High-level architecture description
- High-level risks and challenges
- **Do not** propose solutions or modernization here

---

### 📌 Section 2 — File Inventory

#### 2.1 Count of files
- Count all `.c`, `.h`, `.ini`, `.csv` files

#### 2.2 File table

| File | Type | Purpose | LOC Estimate | Notes |
|------|------|---------|-------------|------|
| ui_menu.c | C | Menu and prompts | 220 | UI to CAD coupling |
| cad_plate.c | C | Plate logic | 130 | Param modeling |

---

### 📌 Section 3 — Function Inventory

#### 3.1 Count and distribution
Provide:

- Total number of functions
- Avg LOC/function
- Top 10 largest functions

#### 3.2 Function index table

| Function | File | LOC | Category | Notes |
|---------|------|-----|----------|------|
| create_plate() | cad_plate.c | ~110 | CAD geometry | UF_MODL usage |
| process_batch() | job_batch.c | ~170 | Batch job execution | CSV parsing |

#### Categories:
- **UI Input**
- **CAD Geometry**
- **Batch Processing**
- **Configuration Parsing**
- **Reporting / Logging**
- **Utility**

---

### 📌 Section 4 — Configuration & Data Analysis

#### 4.1 config/templates.ini
Analyze:
- Sections
- Default values
- Parameter groups

#### 4.2 config/jobs.csv
Analyze:
- Columns
- Expected value types
- Error handling or lack thereof

#### 4.3 Hardcoded configuration values
Search for constants like:

- Diameters
- Offsets
- Hole patterns
- Fillet radii
- Plate default sizes

Document all discovered magic numbers.

---

### 📌 Section 5 — Runtime, Build & Deployment

Document:

- Compilation method (gcc, MSVC, NX build environment)
- Include directories
- Required NX UFunc header paths
- Linker dependencies
- NX environment variables (e.g., `UGII_USER_DIR`, `UGII_BASE_DIR`)
- Project run lifecycle:
  - `UF_initialize()`
  - `ufusr()`
  - `ufusr_ask_unload()`
  - `UF_terminate()`

Estimate if:

- Deployment is manual copy into NX user folder  
- No CI/CD or build automation exists  
- No environment separation (dev/test/prod)

---

### 📌 Section 6 — UFunc API Dependency Mapping

Create a **full registry** of UFunc calls used, grouped by subsystem:

#### 6.1 UF_UI API

- `UF_UI_ask_string`
- `UF_UI_open_listing_window`
- `UF_UI_write_listing_window`
- `UF_UI_close_listing_window`

#### 6.2 UF_MODL API (CAD modeling)

- `UF_MODL_create_boss`
- `UF_MODL_create_cylinder`
- `UF_MODL_create_chamfer`
- `UF_MODL_create_fillet`
- `UF_MODL_create_perimeter`

#### 6.3 File IO
- `fopen`
- `fscanf`
- `fprintf`

#### 6.4 Configuration
- Manual CSV/INI parsing

#### API Mapping Table

| UFunc API | File(s) | Purpose |
|----------|--------|--------|
| UF_MODL_create_boss | cad_plate.c | create cylindrical boss |
| UF_UI_ask_string | ui_menu.c | prompt user for parameters |

⚠️ Must be **based on code analysis**, not assumptions.

---

### 📌 Section 7 — Code Quality & Technical Debt

Document ALL technical debt categories:

- **Global variables**
- **Magic numbers**
- **Large functions (>150 LOC)**
- **Tight coupling between UI & CAD logic**
- **Error handling inconsistencies (`ifail`)**
- **Duplicated code between modules**
- **No abstraction for UFunc types**
- **File system I/O inside business logic**

You MUST identify at least **10+ specific issues**.

---

### 📌 Section 8 — Natural Modular Boundaries (Modernization Mapping Insight)

Map **legacy modules → modernization units**, WITHOUT suggesting implementation:

| Legacy Module | Purpose | Suggested .NET Domain Service | Suggested React UI Page |
|--------------|---------|-------------------------------|------------------------|
| cad_plate.c | Plate geometry | PlateService | PlatePage |
| cad_bolt_circle.c | Bolt pattern logic | BoltCircleService | BoltCirclePage |
| job_batch.c | Batch execution | BatchJobService | BatchJobsPage |

Provide at least 6 mappings.

---

### 📌 Section 9 — Risks, Constraints & Unknowns

A proper **risk and unknown section** MUST be present:

#### Risk Categories:

- Technical
- Architectural
- Operational
- Dependency
- Configuration

#### Risk Table Example:

| Risk | Impact | Notes |
|-----|-------|------|
| Tight NX UFunc coupling | High | Hard to isolate logic |
| CSV schema not documented | Medium | Might break batch migration |

List **10+ risks** minimum.

---

### 📌 Section 10 — Required Clarification Questions

Ask at least **12–20 questions** relevant to modernization planning.

Examples:

- Which NX CAD versions must be supported?
- Can the UI logic be replaced entirely or must it coexist?
- Does the system require CAD part persistence?
- Who maintains the INI files?
- Are CAD templates external or code-generated?

---

## 6. Final Style Rules

- Do NOT recommend .NET or React solutions in this document
- Do NOT propose migration strategy
- Do NOT modify code
- Only **analyze and report**

Every section must be:

- Structured
- Explicit
- Reproducible
- Traceable to observable code facts

---

## 7. Done Criteria

As-Is analysis is complete when:

- **Every file** is inventoried  
- **Every function** is listed  
- **Every UFunc API** call is cataloged  
- **Every configuration file** is analyzed  
- **Top technical debts** are documented  
- **Modular boundaries** are suggested  
- **Risks and unknowns** are explicitly stated  
- **Clarification questions** are listed  

NO content omitted.  
NO section skipped.  
NO future-state implementation references.

---
