# Project Structure Extraction Prompt  
*(Legacy C / NX-UG UFunc → Modernization Baseline)*

This document is a **complete LLM prompt** for performing a **project structure analysis** of a legacy procedural C codebase using Siemens NX/UG UFunc APIs. The generated output must create a **clear, factual, current-state document** suitable for modernization planning to .NET backend + React UI (optional future planning, but NOT required in analysis portion).

---

## 1. Role

You are acting as a **software archaeologist** and **legacy system analyst** with expertise in:

- Procedural C codebases
- Siemens NX / UG UFunc API structure
- File I/O and UI handler patterns in CAD automation
- Codebase mapping and static structure extraction
- Modularization planning for modernization work

---

## 2. Objective

Your output is **not a migration plan** — it is a **complete, neutral, detailed documentation of what exists today** in `[Project Name]`.

The final document must show:

- Physical file structure
- Folder hierarchy
- Modules and responsibilities
- Dependency relationships
- Configuration assets
- Input/output patterns
- Naming conventions
- Cross-cutting utilities
- Code smells and duplication

**Do not recommend solutions or future architecture unless asked.**  
Focus exclusively on **as-is structure**.

---

## 3. Tone & Style

- **Tone:** Neutral, technical, non-opinionated  
- **Style:** Report format  
- **Output:** Single Markdown `.md` file  
- **Content:** Precise and structured, not narrative  

Use headings, bullet points, tables, and code blocks.

---

## 4. Required Sections (MANDATORY)

The output MUST contain the following sections **in this exact order**:

---

# 1. Top-Level Directory Structure

### 1.1 File tree layout
Example format:

```
/src
/include
/lib
/config
/assets
/tools
/docs
/tests
/build
```

### 1.2 Observations
- Are UI and CAD logic mixed together?
- Are config files stored alongside source files?
- Are `include` headers separate from implementation?
- Presence of vendor / SDK includes?

---

# 2. Source Code Modules Overview

List **every `.c` / `.h` file** with a **1–3 sentence description** of its purpose.

Format:

| File | Responsibility | Notes |
|------|--------------|------|
| `ui_menu.c` | UI command prompt handling | Likely presentation layer |
| `cad_plate.c` | Geometry generation for plate shape | Model creation logic |
| `job_batch.c` | Reads CSV and executes CAD jobs | Procedural automation |

Include ALL files — no summaries like “etc.” allowed.

---

# 3. Dependency Relationship Mapping

For each source file, specify:

- Internal dependencies (calls to other modules)
- External dependencies (UFunc APIs, C standard library)
- Configuration or file dependencies (INI, CSV, JSON, etc.)

### 3.1 Table Format

| File | Depends On (Internal) | Depends On (External) |
|------|----------------------|----------------------|
| `ui_menu.c` | `cad_plate.c` | `UF_UI_*` |
| `cad_bolt_circle.c` | `cad_utils.c` | `UF_MODL_*` |
| `job_batch.c` | `cad_plate.c` | `fopen`, `sscanf` |

### 3.2 Dependency Classification

- UI
- Modeling
- Utility
- Configuration
- File I/O
- Batch processing

---

# 4. Naming and Organization Conventions

Analyze:

- File prefixes (e.g., `cad_`, `ui_`)
- Common helper utilities (`*_utils.c`)
- Duplicate naming / inconsistent naming

State what appears to be a **pattern**.

---

# 5. Cross-Cutting Code (MUST identify)

List:

- Logging mechanisms (printf, UF_UI listing window, custom macros)
- Error management patterns (`ifail`, magic return values)
- Memory handling strategies (malloc/free, stack buffers)
- Global variables

---

# 6. Configuration Assets

Identify **all configuration mechanisms**:

- `.ini` files  
- `.csv` job definitions  
- Embedded text parameters  
- Hard-coded values  

Produce a list of configuration input sources with file names.

Example output:

| File Type | Purpose | Associated Module |
|----------|--------|------------------|
| `templates.ini` | Default geometry parameters | `cad_utils.c` |
| `jobs.csv` | Batch job definition | `job_batch.c` |

---

# 7. Execution Flow Diagrams (Text-Only)

Produce **text descriptions** of:

- UI-driven flow
- Batch automation flow
- CAD geometry calculation flow

Suggested style:

```
User → UF_UI_ask_string → cad_plate.c → UF_MODL_create_prism → NX model updated
```

---

# 8. Code Complexity Signals (Factual Observations)

Identify high-risk structural issues such as:

- Very large functions (>200 lines)
- Nested `if` / `switch` logic
- Repeated code segments
- No header separation
- Multi-responsibility modules

🛑 **Do not suggest solutions — only document facts.**

---

# 9. Duplicate Logic

List repeating patterns like:

- Calculation formulas copy/pasted
- Geometry creation repeated in multiple files
- File parsing repeated across modules

Format:

| Pattern | Files Detected |
|--------|---------------|
| Plate thickness read logic | `ui_menu.c`, `job_batch.c` |

---

# 10. Unused / Legacy / Experimental Files

Scan for:

- Files not referenced
- Code commented out
- Disabled compiler flags
- Test utilities / sample code

Output must include:

- File name  
- Evidence (e.g., no call references)  
- Suggested classification  
  (dead code, sample, archive, experiment)  

---

# 11. Final Output Requirement

The final output MUST be called:

```
Project_Structure_Report.md
```

And MUST contain:

- **Exact folder/file inventory**
- **Dependency mapping tables**
- **Input/output sources**
- **Execution flow descriptions**
- **Evidence-based structure notes**

---

## 5. Rules (Hard Requirements)

- MUST describe legacy structure ONLY  
- MUST NOT produce future architecture design  
- MUST NOT reference Spring/Java/Maven  
- MUST be able to run on any C + UFunc project  
- MUST be exhaustive and untruncated  
- MUST produce structured Markdown  

---

End of File.
