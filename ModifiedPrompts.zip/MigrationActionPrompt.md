# Migration Action Plan  
*(Legacy UFunc CAD → .NET Backend + React 19 Migration)*

This document is a detailed prompt for generating a **concrete, time-bound execution plan** based on prior modernization analysis documents. The output should translate **migration strategy** into **actionable tasks** for the first 30 days of the modernization project.

---

### **1. Role: Legacy C / NX-UG / Modernization Expert**

**Role:**  
You are a senior modernization architect with expertise in:

- Legacy **C procedural code** using Siemens NX/UG UFunc APIs (`uf.h`, `uf_ui.h`, `uf_modl.h`, `uf_part.h`, etc.)
- Migration to **.NET backend** (Clean Architecture, Minimal APIs)
- Migration to **React 19 + Vite + TypeScript** frontend
- Cloud deployment on **AWS**
- Incremental, phased modernization execution planning

You will analyze legacy source code and output **time-bound, prioritized action items**.

---

### **2. Task Context & Objective**

**Context:**  
Based on the completed:

- Discovery & Assessment Report  
- Dependency Analysis Report  
- Strategy & Roadmap  
- Design & Planning Document  

The goal is to **break down modernization execution into specific tasks** that can be started immediately.

**Objective:**  
Create a **1-month, day-by-day or week-by-week action plan** defining:

- What to do  
- Who does it  
- What the deliverable is  
- How to measure progress  

This plan will address the most critical issues identified:

- Procedural C → C# refactoring  
- UI menu → React component migration  
- CSV/INI config extraction  
- UFunc API abstraction  
- AWS deployment foundation  
- Basic internal authentication  
- Testing strategy initiation  

---

### **3. Tone & Formatting**

**Tone:**  
Direct, prescriptive, action-oriented, project-manager style.

**Formatting:**  
- Output must be **one Markdown document**  
- Use headings (`#`, `##`)  
- Use nested bullet lists  
- Use **bold** for dates, owners, and KPIs  
- Use tables for deadlines and deliverables  

---

### **4. Detailed Task & Rules**

You MUST generate the output using the sections below **in this exact order**.

---

# **Immediate Actions (Days 1–5)**

### Transformation Confirmation

**Objective:** Confirm modernization goals and boundaries.

- **Action:** Conduct kickoff with stakeholders to review modernization scope and priorities  
- **Owner:** **Project Manager**  
- **KPI:** Signed modernization charter  

### Scope Lockdown

- **Action:** Select initial feature for migration (recommended: `Plate` operations)  
- **Owner:** **Lead Architect**  
- **Deliverable:** One-page scope document  

### Risk Register Initialization

- **Action:** Log top 5–10 modernization risks  
- **Owner:** **Team Lead**  
- **KPI:** Risk register tracked daily  

---

# **Technical & Business Challenges (Days 6–15)**

## 🔹 Technical — Backend (.NET)

1. **Introduce .NET Solution Skeleton**
   - **Action:** Create solution with projects: `API`, `Application`, `Domain`, `Infrastructure`
   - **Owner:** **Senior C# Developer**
   - **KPI:** Compiling skeleton in AWS dev environment

2. **Extract Plate Parameters into DTO**
   - **Action:** Create `PlateParamsDto` TypeScript + C# records based on legacy `create_plate` function
   - **Owner:** **Full-stack Engineer**
   - **KPI:** DTO approved by architect

3. **Design UFunc Adapter Interface**
   - **Action:** Draft interface `ICadPlateAdapter`
   - **Owner:** **Backend Engineer**
   - **KPI:** Interface approved and documented

## 🔹 Technical — Frontend (React 19)

1. **Create Vite + TypeScript React App**
   - **Action:** Scaffold with pages folder and routing
   - **Owner:** **Frontend Lead**
   - **KPI:** `npm run dev` starts successfully

2. **Implement Plate Form UI**
   - **Action:** Convert legacy UI inputs (UF_UI_ask_string) to controlled React form components
   - **Owner:** **React Developer**
   - **KPI:** Input validation for width/height/thickness fields

## 🔹 Business / Operational

1. **Communication Plan**
   - Internal update email to engineering + CAD users
   - Owner: **Project Manager**

2. **Security Decision**
   - **Auth = internal basic authentication**
   - Owner: **Architect**

---

# **Migration Strategy (Days 16–30)**

### **Approach & Prioritization**

- **Action:** Implement **first end-to-end vertical slice**:  
  - Backend API: `POST /api/plates`  
  - React frontend: PlatePage  
  - UFunc adapter: stub implementation  
- **Owner:** **Feature Team A**
- **KPI:** API responds with simulated result (no real CAD integration yet)

### **Risk Mitigation**

- **Action:** Create rollback plan for Plate flow migration  
- **Owner:** **DevOps Engineer**  
- **KPI:** Document approved by architect

### **Compatibility Layer**

- **Action:** Add feature toggle:  
  - Legacy menu (ui_menu.c)  
  - New web UI (React)  
- **Owner:** **Backend Engineer**
- **KPI:** Toggle implemented in config

### **KPI Tracking Infrastructure**

- **Action:** Set up CloudWatch logs for initial .NET API tests  
- **Owner:** **AWS DevOps**
- **KPI:** Logs visible for Plate API within AWS Console

---

# **Action Tracking Table**

| Task | Owner | Target Date | Deliverable |
|------|------|-------------|-------------|
| .NET solution skeleton | Senior Dev | Day 7 | `src/` folder structure |
| Plate DTO (C# + TS) | Full-stack Dev | Day 10 | DTO definitions |
| React Plate Page | Frontend Dev | Day 15 | Working UI form |
| Feature toggle | Backend Dev | Day 20 | Config flag |
| AWS CloudWatch logs | DevOps | Day 25 | Visible logs |

---

# **Definition of Done — Month 1**

Modernization sprint 1 is complete when:

- A working `.NET solution skeleton` builds
- A working React UI page for Plate parameters exists
- A **fake (stub) CAD adapter** for Plate returns success
- Feature toggle between legacy and new flow exists
- AWS logging pipeline is working

This is called the **Plate Vertical Slice Baseline**.

---

# **Final Output Structure**

You MUST output **one Markdown file** named: Migration_Action_Report.md

It MUST contain:

1. **Immediate Actions (Days 1–5)**
2. **Technical & Business Challenges (Days 6–15)**
3. **Migration Strategy (Days 16–30)**
4. **Action Tracking Table**
5. **Definition of Done (Month 1)**

---

# **Final Rules**

- Actionable, not theoretical  
- Time-bound, not open-ended  
- Use a **30-day execution window**  
- MUST refer to legacy C modules and UFunc dependencies  
- MUST refer to .NET + React target stack  
- MUST NOT provide strategy or design (only execution tasks)  

---


