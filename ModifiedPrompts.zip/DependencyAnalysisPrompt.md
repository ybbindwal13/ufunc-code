# Framework and Dependency Analysis Document  
*(Legacy UFunc CAD → .NET Backend + React 19 Frontend Modernization)*

This document serves as a detailed prompt for generating a comprehensive **technical dependency analysis** of a legacy procedural C project using **Siemens NX/UG UFunc APIs**, with the objective of identifying modernization opportunities and upgrade paths to **.NET backend + React 19 + Vite + TypeScript frontend**, and AWS deployment.

---

### **1. Role: Legacy C / NX-UG / Modernization Expert**

**Role:**  
You are a senior software architect with expertise in:

- Legacy **C/C++ CAD automation**
- **NX/UG UFunc** APIs (e.g., `uf.h`, `uf_ui.h`, `uf_modl.h`, `uf_part.h`, `uf_mb.h`)
- Dependency mapping and inventory
- Modernization strategies targeting:
  - **.NET (Clean Architecture + Minimal APIs)**
  - **React 19 + Vite + TypeScript**
  - **AWS deployment and internal basic authentication**

Your task is to analyze frameworks, libraries, components, and external dependencies used by the legacy project and produce a structured, technical dependency analysis report.

---

### **2. Task Context & Objective**

**Context:**  
Perform a detailed **dependency and framework analysis** of `[Project Name]`, built using procedural C with NX/UG UFunc APIs.

The goal is to create a factual baseline:

- Which APIs, external libs, system dependencies, configuration, and build tools the project relies on
- Where hidden or undocumented dependencies exist
- Which parts of the codebase will create modernization risks

**Objective:**  
Produce a **detailed inventory + upgrade matrix** that will become a core document for planning modernization to .NET + React.

---

### **3. Tone & Formatting**

- **Tone:** Formal, technical, objective
- **Output:** Single **Markdown document**
- Use headings (`#`, `##`), bullet lists, and tables
- **Do not summarize** — provide structured detail

---

### **4. Detailed Task & Rules**

Below is the structure you MUST follow when generating the output document.

---

# **Frameworks in Use**

For each major element of the system:

### **Backend (Legacy C/UFunc)**

Identify:

- UFunc header files in use  
  (e.g., `uf.h`, `uf_ui.h`, `uf_modl.h`, `uf_part.h`, `uf_mb.h`)
- Major API groups  
  (UI, modeling, geometry, selection, file I/O, assembly)
- CAD dependencies  
  (NX version, environment constraints)

Document:

- Purpose of each API group
- Suggested modernization abstraction

Example statement:

> `UF_MODL_create_boss` used for cylindrical boss generation in `cad_plate.c`

### **Frontend (Legacy UI)**

Legacy UI elements include:

- `UF_UI_ask_string`
- `UF_UI_open_listing_window`
- `UF_UI_write_listing_window`

Document:

- All interactive UI functions
- Input and output limitations

> These legacy UI calls will be replaced by **React 19 form-based UI components**.

---

# **External Dependencies**

## **Inventory**

### Legacy Dependencies

- **NX/UG UFunc API**
- **Standard C library**
- **File I/O and batch processing**:
  - `fopen`, `fgets`, `fprintf`, `sscanf`

### Configuration dependencies

- `.ini` file scheme (`templates.ini`)
- `.csv` batch job scheme (`jobs.csv`)

### Infrastructure dependencies

- Manual deployment into NX environment
- Build dependencies:
  - GCC/MSVC  
  - Include paths (NX SDK path)  

## **Categorized List**

Provide a complete categorized list:

- **NX CAD APIs**
- **UI handler libraries**
- **Modeling geometry API**
- **File I/O**
- **INI/CSV parsing logic**
- **Configuration files**

## **Vulnerability & Deprecation Review**

Flag potential modernization risks:

- Legacy file parsing with no validation  
- INI configuration without schema  
- CSV batch jobs without input sanitization  
- Hardcoded strings / magic numbers  
- No logging abstraction  
- NX SDK version unknown / unsupported risk  

---

# **Current vs. Target Versions**

## **Version Assessment**

Identify all current dependencies:

- UFunc API header files
- Compiler version
- NX SDK version
- CSV parser logic
- INI configuration logic

### **Target Version Proposal**

For each legacy dependency, propose modern technology replacements:

| Legacy Component | Current State | Target Tech |
|-----------------|--------------|------------|
| NX/UG UFunc UI functions | UF_UI_ask_string | React 19 form components |
| CSV job executor | job_batch.c | C# service + EF Core / minimal DB |
| INI config loader | templates.ini | AWS Parameter Store / appsettings.json |

---

# **Compatibility Considerations**

### **Breaking Changes**

Document modernization impacts:

- C procedural code → C# OOP
- UI prompt → browser UI
- Direct UFunc call → adapter/service abstraction
- INI parsing → strongly typed config
- CSV jobs → API-based job execution

### **Inter-Dependency Conflicts**

List modernization risks:

- UI code tightly coupled to CAD logic
- NX API not directly available in .NET
- File I/O located inside CAD business logic

### **Codebase Impact Areas**

Identify areas likely needing refactor:

- Large functions
- Global variables
- Inconsistent error handling (`ifail`)
- Duplicate logic

---

# **Upgrade Strategy**

### **Phased Approach**

Propose modernization in **phases**:

1. Extract config parsing
2. Wrap UFunc calls in adapters
3. Introduce .NET API layer
4. Build React UI screens feature-wise
5. Decommission legacy UI functions

### **Rollback Plan**

Include:

- Legacy menu coexistence
- Feature toggles
- Parallel execution
- Safe fallback to UFunc UIs

### **Testing Strategy**

- Unit tests (backend C#)
- Integration tests (API calls)
- UI tests (React)
- Manual NX validation tests

---

# **Dependency Upgrade Matrix**

Provide a **full upgrade table**:

| Component / Library | Current Version | Target Version | Upgrade Notes |
|--------------------|----------------|----------------|---------------|
| UFunc UI calls | UF_UI_ask_string | React 19 forms | Replace prompt handling |
| UFunc CAD calls | UF_MODL_... | .NET CAD adapter | Wrap in abstraction layer |
| Config (.ini) | File parsing | AWS Parameter Store | Remove magic parsing |
| CSV batch jobs | fopen + fgets | .NET Background Services | API-driven batch |
| Logging | printf | Serilog / AWS CloudWatch | Structured logging |
| Build system | Manual GCC | CI/CD AWS pipeline | Automated deployment |

---

# **Final Deliverable**

Produce a **Markdown document** named: Dependency_Analysis_Report.md

with the following sections:

- **Frameworks in Use**
- **External Dependencies**
- **Current vs Target Versions**
- **Compatibility Considerations**
- **Upgrade Strategy**
- **Dependency Upgrade Matrix**

This document must be:

- **Technical and specific**
- Based on **code inspection**
- Free of speculation  
- Ready for use in modernization planning

---


