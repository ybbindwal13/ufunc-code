# Dependency Risk & Vulnerability Report  
*(Legacy UFunc CAD System → Modern .NET + React Migration)*

This document serves as a detailed prompt for generating a comprehensive **dependency risk report** for a legacy procedural C application built using **Siemens NX/UG UFunc APIs**, with the goal of identifying security, maintainability, and modernization issues before migration to a modern **.NET backend + React 19 (Vite + TypeScript) frontend** with AWS deployment and internal basic authentication.

---

## 1. Role: Legacy C / NX-UG / Modernization Expert

You are a senior modernization expert specializing in:

- Legacy **C/C++ CAD automation**
- **NX/UG UFunc** API versioning and deprecation
- Code dependency and risk mapping
- Incremental modernization toward:
  - **.NET backend (Clean Architecture)**
  - **React 19 + Vite + TypeScript UI**
  - **AWS ECS/Fargate + CloudWatch logging**

Your deliverable is a **formal dependency risk analysis report** suitable for technical leadership and modernization planning.

---

## 2. Task Context & Objective

**Context:**  
Legacy NX UFunc software tends to accumulate:

- Deprecated UFunc API calls
- Unsafe file I/O
- Hardcoded strings and parameters
- Manual CSV/INI parsing with no validation
- Tight coupling of UI and CAD logic
- Lack of abstraction around geometry creation

These pose modernization risks when porting to **.NET microservices + React UI**.

**Objective:**  
Produce a dependency risk report that:

- Identifies risky legacy APIs, libraries, and coding patterns
- Ranks severity and potential business impact
- Suggests viable modernization approaches per dependency
- Prioritizes remediation actions

⚠️ This is a **risk analysis only** — not a migration strategy.

---

## 3. Tone & Formatting

- **Tone:** Formal, technical, objective  
- **Format:** Output a **Markdown (.md)** file  
- **Structure:** Use headings, bullet lists, tables, and risk matrices  
- **No placeholders or truncation**  

---

## 4. Risk Categorization Model

Define four risk tiers specific to NX/UFunc modernization:

### **Tier 1 — Very High Risk**
- Deprecated UFunc UI calls (`UF_UI_ask_string`, `UF_UI_close_listing_window`)
- Raw file handling (`fopen`, `fgets`, `sscanf`) without validation
- Unsafe string operations (`sprintf`, `strcpy`)

### **Tier 2 — High Risk**
- Legacy modeling APIs (`UF_MODL_create_*`)
- No error checking for `ifail` return codes
- Magic numeric values in geometry calculation

### **Tier 3 — Medium Risk**
- Unstructured configuration parsing (INI, CSV)
- Weak type safety
- Duplicate logic in multiple modules

### **Tier 4 — Low Risk**
- Utility functions that can remain temporarily
- Simple constant definitions and logging macros

---

## 5. Identification of Risky Dependencies

### 5.1 Manual and Automated Scanning

Recommended scan commands:

```bash
grep -R "UF_UI_" -n ./src
grep -R "UF_MODL_" -n ./src
grep -R "fopen(" -n ./src
grep -R "sscanf" -n ./src
grep -R "sprintf" -n ./src
```

### 5.2 Output Fields (MUST be collected for every instance)

- File name  
- Line number(s)  
- API / function call  
- Risk level  
- Suggested fix (at high level)  
- Notes  

### 5.3 Example Instance Table

| File | Line(s) | API / Pattern | Risk | Notes |
|------|--------|---------------|------|------|
| ui_menu.c | 42, 103 | UF_UI_ask_string | Very High | Legacy NX UI API |
| cad_plate.c | 88 | UF_MODL_create_cylinder | High | Modeling API may change |
| job_batch.c | 25 | fopen | Very High | Raw unsafe I/O |
| cad_utils.c | 33 | sscanf | High | No input validation |

---

## 6. Risk-Level-to-Action Mapping

### 6.1 Required Remediation Patterns (MANDATORY)

- **Replace unsafe UI input**  
  Legacy: `UF_UI_ask_string`  
  Target: React form fields + minimal Validations

- **Wrap modeling calls**  
  Legacy: `UF_MODL_create_*`  
  Target: C# service interface (e.g., `ICadPlateAdapter`)

- **Eliminate raw file I/O**  
  Legacy: `fopen`, `sscanf`  
  Target: C# configuration (`IConfiguration`), AWS Parameter Store

- **Add structured logging**  
  Legacy: `printf` or nothing  
  Target: Serilog + CloudWatch logs in AWS

### 6.2 Migration Effort Estimates

| Dependency Pattern | Effort | Notes |
|-------------------|-------|------|
| UI API → React | Medium | Form design + validation |
| Modeling API wrapping | High | Needs abstraction design |
| File parsing rewrite | Medium | DTOs + config binding |
| Logging modernization | Low | Centralized logging pipeline |

---

## 7. Risk Summary Dashboard (Leadership Format)

### 7.1 Counts by Tier

| Risk Tier | Count | Color |
|---------|------|------|
| Very High | ## | 🔴 |
| High | ## | 🟠 |
| Medium | ## | 🟡 |
| Low | ## | 🟢 |

### 7.2 Worst Dependencies

- Legacy UI API (`UF_UI_ask_string`)
- Raw file parsing (`fgets`, `sscanf`)
- Unvalidated CSV processing (`job_batch.c`)
- Direct modeling calls (`UF_MODL_create_*`)

### 7.3 Business Impacts

- NX version upgrade breaks production flow  
- Corrupted CAD models  
- Unsafe user input risk in React UI migration  
- Higher modernization cost if API wrapping deferred  

---

## 8. Formal Remediation Recommendations

### 8.1 Near-term actions (Sprint 1)

- Identify ALL `UF_UI_ask_string` occurrences
- Replace CSV / INI parsing with DTO + validation plan
- Introduce feature toggles for new .NET endpoints

### 8.2 Mid-term actions (Sprint 2–3)

- Wrap modeling logic (`UF_MODL_*`) behind **clean interfaces**
- Start converting single feature vertical slice (Plate)

### 8.3 Future-state controls

- Static scanning as part of CI/CD
- Risk review every NX upgrade cycle
- Migration backlog with estimates

---

## 9. Output Requirements

Produce **one Markdown file** named:

```
Dependency_Risk_Report.md
```

It MUST include:

- Tiered risk classification
- Code-level findings (file + line + API)
- Recommended modernization actions
- Effort estimates
- Risk dashboard

### Rules:

- DO NOT mention Java/Spring/Maven  
- DO NOT truncate content  
- MUST refer only to **legacy C + NX UFunc + .NET + React modernization context**  
- MUST include tables and real dependency examples  
- MUST be written as if you are documenting an enterprise modernization review  

---

## 10. Done Criteria

The report is **complete** when:

- All major risky dependencies are identified  
- Every UFunc UI and modeling call is risk-ranked  
- Raw file and string operations are documented  
- Remediation mapping exists for each risk tier  
- Leadership summary + dashboard are generated  
- No section is missing or “to be filled later”  

---
