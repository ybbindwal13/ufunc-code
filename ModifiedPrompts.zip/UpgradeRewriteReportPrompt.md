# Upgrade & Rewrite Strategy Report  
*(Legacy C + NX/UG UFunc → .NET Backend + React 19 Rewrite)*

This document is a complete LLM prompt for creating a technical **rewrite assessment report** for a legacy **procedural C** codebase using **Siemens NX/UG UFunc APIs**. The report will identify rewrite requirements, modernization priorities, risks, and recommended strategy to migrate toward a modern **.NET backend + React 19 (Vite + TypeScript)** architecture deployed on AWS using internal basic authentication.

---

## 1. Role: Modernization Architect

You are a senior architect responsible for legacy system transformation. You have expertise in:

- Procedural C code review
- NX/UG UFunc API evolution and version compatibility
- Clean Architecture in .NET
- REST API design with C#
- React 19, Vite, TypeScript
- AWS deployment strategy
- CI/CD automation

Your output must be **structured, formal, and comprehensive**.

---

## 2. Task Context & Objective

**Context:**  
The legacy application contains multiple categories of logic:

- **UI logic** using UFunc (e.g., `UF_UI_ask_string`)
- **CAD modeling logic** using NX geometry APIs (`UF_MODL_*`)
- **File parsing** using C standard library (`fopen`, `sscanf`, `sprintf`)
- **Configuration** stored in `.ini` and `.csv`
- **Batch automation** embedded in procedural loops

**Objective:**  
Produce a complete modernization rewrite analysis to understand what must be replaced, wrapped, adapted, or rewritten from scratch.

This report must:

- Identify rewrite scope  
- Detail rewrite risks  
- Recommend rewrite strategies  
- Provide effort and priority guidelines  

---

## 3. Tone & Formatting Requirements

- **Tone:** Formal, technical, neutral (not marketing language)
- **Output:** Single `.md` document
- **Structure:** Use headings, bullet lists, tables, and code examples
- **Detail level:** Senior architect / modernization consultant level

---

## 4. Affected Components Identification

Document **every system area impacted by the rewrite**.

### 4.1 UI Components

Identify any code using UFunc UI calls:

- `UF_UI_ask_string`
- `UF_UI_write_listing_window`
- `UF_UI_display_message`
- `UF_UI_close_listing_window`

Rewrite reasoning:

- Needs conversion to React controlled components  
- Requires client-side validation  
- Requires HTTP POST/PUT calls to `.NET API`

### 4.2 CAD Modeling Logic

Identify modeling APIs:

- `UF_MODL_create_block`
- `UF_MODL_create_cylinder`
- `UF_MODL_create_cone`
- `UF_MODL_edit_feature`

Rewrite reasoning:

- Must be wrapped behind `.NET adapter interface`
- Must separate geometry parameters from execution
- Must convert procedural flow into async API

### 4.3 File Parsing Logic

Legacy code patterns to flag:

- `fopen`
- `fgets`
- `sscanf`
- `sprintf`
- `strtok`

Rewrite reasoning:

- Replaced by DTO parsing in `.NET`
- Validated via Data Annotations or FluentValidation
- CSV ingestion moved to **API upload** flow

### 4.4 Configuration Assets

Legacy configuration:

- `.ini` files
- `.csv` templates
- Hardcoded geometry defaults

Rewrite destination:

- `appsettings.json`
- AWS Parameter Store
- Type-safe environment configuration

---

## 5. Code Section Analysis (By File)

Create a **file-level rewrite matrix**:

| Legacy File | Rewrite Action | Reason |
|------------|----------------|-------|
| `ui_menu.c` | Full rewrite | UFunc UI prompt replaced by React form components |
| `cad_plate.c` | Adapter + partial rewrite | Must wrap NX APIs and extract geometry parameters |
| `job_batch.c` | Full rewrite | File parsing must become REST job submission |
| `cad_utils.c` | Consolidate + refactor | Common helper logic duplicated |

---

## 6. Mandatory Rewrite Requirements

### 6.1 UI Layer Rewrite Requirements

- Convert prompt UI → **React forms**
- Implement controlled state management using **TypeScript**
- Provide per-field validation rules
- Support file upload for batch jobs

### 6.2 CAD Logic Rewrite Requirements

- Create **C# domain services**
- Implement NX modeling behind **adapter classes**
- Define **DTO models** for geometry parameters

### 6.3 File Handling Rewrite Requirements

- Replace raw C file I/O with C# services for:
  - CSV parsing using `CsvHelper`
  - Configuration binding using `IConfiguration`
- Input sanitization for all numeric fields

### 6.4 Error & Logging Rewrite Requirements

Legacy:

- `ifail`
- No structured error handling
- `printf` debug logging

Modern:

- Exception filters
- Serilog
- CloudWatch log retention policy
- Central correlation ID for CAD operations

---

## 7. Rewrite Strategy Options (Must Propose 3)

### Strategy 1: Strangler Pattern (RECOMMENDED)

- Build new `.NET + React` components beside legacy system
- Gradually turn off UFunc operations
- Use routing/feature toggles to switch behavior

### Strategy 2: Vertical Slice Rewrite

Rewrite single workflow end-to-end:

- Input form (React)
- API endpoint (`POST /api/plate`)
- CAD service in `.NET`

### Strategy 3: Full Rewrite (Big Bang)

- Replace entire procedural code at once  
- Only suitable for small codebases (<5k LOC)

> MUST state risks explicitly:
> - NX regression risk
> - Production downtime
> - No fallback mechanism

---

## 8. Effort Estimate & Prioritization

### 8.1 Rewrite Priority Matrix

| Component | Priority | Complexity |
|----------|---------|-----------|
| UI Menu → React | High | Medium |
| CAD Plate logic | High | High |
| Batch job processing | High | High |
| Utilities | Medium | Low |

### 8.2 Time Estimation (Example)

- React UI: 3–6 weeks
- .NET API design: 4–8 weeks
- CAD adapter layer: 6–10 weeks
- Batch job rewrite: 6–12 weeks

---

## 9. Risks & Mitigation

### Top Risks

- Unknown NX API behavior under new .NET calling flow
- Missing input validation causing model corruption
- Hardcoded dimensions producing incorrect models
- CSV schema variability

### Mitigations

- Create **CAD adapter interface**
- Introduce **API schema validation**
- Implement **rollback UX** (legacy button)
- Archive legacy CSV/INI examples

---

## 10. Final Output Requirements

You MUST output a `.md` file named:

Upgrade_Rewrite_Report.md

It MUST include:

- Full rewrite strategy
- File-level analysis
- Recommended approach
- Risk & mitigation table
- Timeline and resource estimate

---

## 11. Rules

- MUST reference legacy **C + NX UFunc → .NET + React rewrite**
- MUST NOT reference Java/Maven/Spring
- MUST include tables and code examples
- MUST provide detail, not generic statements
- MUST produce a professional architect-level report
- MUST be untruncated

---

End of File.
