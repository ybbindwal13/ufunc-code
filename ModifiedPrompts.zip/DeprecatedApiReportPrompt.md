# Deprecated API Report Generation  
*(Legacy UFunc CAD → Modern .NET + React Migration)*

This document serves as a detailed prompt for generating a comprehensive **deprecated API usage report** for a legacy procedural C codebase developed using **Siemens NX/UG UFunc APIs**. The report output must be an actionable modernization guide to help identify, classify, and prioritize remediation of outdated or risky API usage before migrating to **.NET backend + React 19 + TypeScript UI** on AWS.

---

## 1. Role: Legacy C / NX-UG / Modernization Expert

**Role:**  
You are a senior modernization architect specializing in:

- Legacy **C / C++ CAD automation**
- **NX/UG UFunc API evolution** (deprecated/changed functions across NX versions)
- Large-scale incremental modernization programs
- Migration toward:
  - **.NET backend with Clean Architecture**
  - **React 19 + Vite + TypeScript frontend**
  - **AWS deployment and internal basic authentication**

Your deliverable is a **formal deprecated API risk analysis report**.

---

## 2. Task Context & Objective

**Context:**  
Legacy NX UFunc APIs evolve over time — many older functions become deprecated, renamed, or replaced by newer, safer modeling or UI APIs. The legacy codebase may contain:

- Outdated UFunc UI calls
- Modeling calls superseded by newer NX APIs
- Undocumented CAD geometry construction functions
- Unsupported I/O patterns and unsafe string handling

**Objective:**  
Generate a detailed, actionable document that:

- **Identifies deprecated API usage**
- **Shows file locations and line numbers**
- **Rates modernization risks**
- **Suggests replacement APIs or architectural patterns**
- **Proposes migration difficulty estimates**

⚠️ This is a code analysis prompt — do NOT propose full application migration here.

---

## 3. Tone & Formatting

- **Tone:** Formal, technical, objective, measurable  
- **Deliverable:** A **single Markdown document**  
- **Structure:** Use `#`, `##`, tables, bullet points, and code blocks  
- **Style:** Evidence-based, not theoretical or generic  

---

## 4. Detailed Task & Rules

The report MUST contain the following sections **in this exact order**:

---

# Identification of Deprecated APIs

### 4.1 Systematic Scan Method
Describe the technique used to locate deprecated or risky calls by:

- Searching for known deprecated UFunc APIs  
- Searching for NX version-specific warnings  
- Searching for legacy C idioms that are error-prone:
  - `gets()`
  - `sprintf()` without bounds
  - Manual string concatenation
  - Manual memory handling

Include explicit patterns to search for, e.g.:

```
grep -R "UF_UI_ask_string" -n ./src
grep -R "UF_MODL_create" -n ./src
grep -R "fopen(" -n ./src
```

### 4.2 Code Examples

Provide actual **deprecated or risky UFunc usage examples** (placeholder format):

```c
int ifail = UF_UI_ask_string("Enter plate width:", widthStr);
```

```c
UF_MODL_create_cylinder( ... );    // Legacy modeling API
```

---

# File Locations

### 5.1 Affected Files

Produce a complete list of all files containing deprecated or risky API usage, such as:

- `src/ui_menu.c`
- `src/cad_plate.c`
- `src/cad_bolt_circle.c`
- `src/job_batch.c`
- `src/cad_utils.c`

### 5.2 Line Numbers & Instances

List each affected line explicitly:

- `src/ui_menu.c`: lines 42, 117, 130  
- `src/cad_plate.c`: line 88  
- `src/cad_utils.c`: lines 25–36

(Use actual positions based on source scan.)

---

# Risk Level Analysis

### 6.1 Risk Categories:

Define these per instance:

- **High Risk:** Removal or behavior change in current NX versions  
- **Medium Risk:** Deprecated but still functional  
- **Low Risk:** Outdated style but safe in short term  

### 6.2 Risk Justification Rules:

Explain why:

- **UF_UI_ask_string** is high risk:  
  ➤ Deprecated UI mechanism, replaced by dialog-based inputs

- **UF_MODL_create_cylinder** risk:  
  ➤ Deprecated in versions 1872+, replaced by NX modeling classes

- **fopen/fgets** parsing risk:  
  ➤ No input validation, unsafe for web-based input migration

### 6.3 Produce a Risk Table:

| File | API | Line | Risk | Reason |
|-----|-----|------|------|-------|
| ui_menu.c | UF_UI_ask_string | 42 | High | Legacy UI replaced by modern dialog APIs |
| cad_plate.c | UF_MODL_create_cylinder | 88 | Medium | Risk of NX version migration |
| job_batch.c | fopen/fgets | 25 | High | Unsafe I/O without validation |

---

# Recommended Changes

### 7.1 Modern Alternatives

For each deprecated API, propose an upgrade:

| Legacy API | Replacement Approach |
|-----------|---------------------|
| `UF_UI_ask_string` | React 19 controlled text fields |
| `UF_MODL_create_cylinder` | Abstraction via `.NET CadModelService` |
| `fopen/scanf` | C# configuration + AWS Parameter Store |

### 7.2 Before / After Code Examples

#### Example 1 — UI Input

**Before (C/UFunc):**
```c
UF_UI_ask_string("Enter thickness:", buffer);
```

**After (.NET + React):**
```tsx
<input type="number" value={thickness} onChange={setThickness} />
```

```csharp
[HttpPost("/api/plate")]
public IActionResult CreatePlate([FromBody] PlateParamsDto dto) { ... }
```

#### Example 2 — File Parsing

**Before (C):**
```c
fgets(line, sizeof(line), file);
```

**After (.NET):**
```csharp
await using var file = new StreamReader(csvPath);
```

#### Example 3 — Configuration

**Before:**
```c
/* Read INI file manually */
```

**After:**
```csharp
builder.Configuration.AddSystemsManager("/cad/config");
```

### 7.3 Effort Estimates (Mandatory)

- **Minor effort:** Direct API mapping (UI → Form input)
- **Medium effort:** Wrapper / adapter creation
- **Major effort:** Full redesign of geometry creation logic

---

# 8. Output Format & Deliverable

Produce **one Markdown document** named:

```
Deprecated_API_Report.md
```

It MUST include:

- Summary of deprecated APIs
- File locations with line numbers
- Risk analysis with justification
- Recommended modernization actions
- Before/after code examples
- Effort estimates

---

# 9. Final Rules

- MUST refer to **legacy C/UFunc APIs**, NOT Java  
- MUST remain specific and measurable  
- MUST NOT propose complete migration strategy  
- MUST NOT suggest .NET code structure beyond direct replacements  
- MUST ensure clarity and evidence-based justification  

---
