# Migration Challenges & Transformation Analysis Document  
*(Legacy C / NX UFunc → .NET + React Migration)*

This document serves as a detailed LLM prompt for generating a **transformation analysis report** of a legacy **procedural C** application built using **Siemens NX/UG UFunc APIs**. The resulting document must provide an evidence-based baseline of migration challenges, risks, and strategic recommendations to modernize the system to a **.NET backend + React 19 (Vite + TypeScript) front end**, deployed on AWS using internal basic authentication.

---

## 1. Task Context & Objective

**Context:**  
You are analyzing the `[Project Name]` legacy codebase as a candidate for modernization. The system contains:

- UI logic using UFunc (e.g., `UF_UI_ask_string`)
- CAD geometry logic using modeling APIs (e.g., `UF_MODL_*`)
- File parsing using C standard library (`fopen`, `sscanf`, `sprintf`)
- Configuration using `.ini` files
- Batch processing using `.csv` job files

**Objective:**  
Produce a **comprehensive transformation analysis report** that:

- Defines modernization scope
- Identifies risks and transformation challenges
- Recommends actionable strategies
- Establishes success criteria and metrics

**Output MUST:**  
- Be technical and precise  
- Use structure and formatting described below  
- Produce a **single Markdown (.md)** file  

---

## 2. Tone & Formatting

- **Tone:** Formal, objective, professional, technical  
- **Formatting:** Use headings (`#`, `##`), bullet lists, and tables  
- **Length:** Detailed (at least 4–8 sentences per subsection)  
- **Perspective:** Systems architect / modernization strategist  

Do **not** speculate — base recommendations on factual code observations.

---

## 3. Required Sections (MANDATORY)

You MUST produce the following sections in **this exact order**:

---

# Section 1 — Transformation Analysis

### 1.1 Modernization Objectives

Document **clear business and technical transformation goals**. Examples:

- Reduce dependency on legacy NX UFunc developer expertise
- Increase maintainability and code readability
- Introduce REST APIs for CAD operations
- Replace prompt-based UX with modern web UI
- Support AWS deployment and CI/CD automation

### 1.2 Transformation Scope

Define what is being migrated:

- Which modules (UI, modeling, batch jobs, config)
- Which legacy files (e.g., `ui_menu.c`, `cad_plate.c`, `job_batch.c`)
- Data and configuration artifacts (`ini`, `csv`, hardcoded dimensions)

Explicitly define **what is NOT part of this phase**.

Examples:

- Keeping CAD geometry logic intact initially, only wrapping it  
- Not replacing NX modeling kernel at this stage  

### 1.3 Opportunities

Identify **improvement vectors**:

- Introduce **DTOs** for strongly typed data exchange  
- Standardize geometry logic into **service classes**  
- Implement validation for all input parameters  
- Data persistence for job execution history  

### 1.4 Risks & Dependencies

List **specific risks tied to CAD/UFunc modernization**:

- NX API version changes  
- Missing documentation for legacy modeling commands  
- Hardcoded numeric geometry parameters  
- Input validation for batch files  
- No logging or error audit trail  

List external dependencies:

- Siemens NX licensing and runtime environment  
- Developer access to UFunc headers & Type Libraries  
- AWS IAM permissions (internal basic auth + role policies)  
- Build/compilers (GCC/MSVC, .NET SDK, Node, Vite)  

---

# Section 2 — Migration Challenges

### 2.1 Technical Challenges

Describe **real engineering obstacles**, not generic “tech challenges”:

- Legacy code uses **procedural flow** → requires modularization  
- UFunc UI APIs are incompatible with web UI  
- Raw file I/O (`fgets`, `sscanf`) creates unpredictable input patterns  
- NX modeling calls need adapter layers for `.NET integration`

Examples:

> Geometry creation logic mixed with UI input in `cad_plate.c` → violates separation of concerns.

> Batch job CSV parsing directly calls modeling APIs → creates tight coupling.

### 2.2 Business Challenges

Examples:

- CAD users require training on new web UI  
- Modernization MUST NOT disrupt production CAD modeling  
- Need ability to **fall back** to legacy flow in case of issues  
- Regulatory requirement: maintain CAD audit logs  

### 2.3 Operational Challenges

Examples:

- No current CI/CD pipeline (deployments are manual)  
- AWS security must be configured (access, roles, encryption)  
- No monitoring / logging infrastructure exists  

State **tools and surfaces** impacted:

- Logging (printf → AWS CloudWatch)
- Config management (ini → Parameter Store)
- Authentication (hardcoded → basic internal)

---

# Section 3 — Recommended Migration Strategy

### 3.1 Approach Models

Choose **exact modernization strategy** and justify:

- **Strangler Pattern** (RECOMMENDED)  
  - Migrate one feature at a time  
  - Keep legacy runtime active until new service stable  

- **Vertical Slice Feature Migration**  
  Example: start with `Plate` geometry module  

- **Feature Toggle + Fallback**  
  Switch between legacy UFunc call and new API call  

### 3.2 Prioritization

Use:

- Complexity  
- Risk level  
- Business criticality  
- User impact  

Example:

| Legacy Feature | Priority | Reason |
|---------------|---------|-------|
| Plate geometry | High | Simple logic + UI mapping easy |
| Bolt circle | Medium | More math + modeling calls |
| Batch job processing | High | Removes CSV complexity |

### 3.3 Risk Mitigation

List **specific mitigation plans** for risks identified:

- Wrap UFunc calls in adapter to prevent breaking NX compatibility  
- Introduce input validation for all geometry parameters  
- Introduce logging for all modeling operations  
- Create formal rollback procedure to restore legacy process  

### 3.4 KPIs for Success

Define **measurable outcomes**:

- 0 crashes on parameter validation in initial release  
- 100% logging coverage for modeling operations  
- Sub-400ms response time for REST API  
- 95% of legacy CSV job cases handled without error  
- No CAD model corruption across first 10 migrations  

KPIs MUST include:

- **User experience**
- **Performance**
- **Reliability**
- **Security**

---

# Section 4 — Final Output Requirements

You MUST output a **single Markdown file** named: Transformation_Analysis_Report.md

The document MUST include:

- Transformation objectives  
- Scope definition  
- Opportunities overview  
- Risks & dependencies  
- Technical / business / operational challenges  
- Migration strategy recommendations  
- KPIs  

---

# Section 5 — Rules

- MUST reference **legacy C + NX UFunc + .NET + React modernization**
- MUST NOT include Java/Maven/Spring content
- MUST NOT be generic — provide detail and examples
- MUST follow the exact structure in Sections 1–4
- MUST be comprehensive enough for PMO planning
- MUST be written in clear Markdown

---

