#ifndef CAD_REPORT_H_INCLUDED
#define CAD_REPORT_H_INCLUDED

#include <uf.h>

typedef struct ReportParams_s
{
    double density;
} ReportParams;

void cad_report_get_default_params(ReportParams *params);
int  cad_report_prompt_user_for_params(ReportParams *params);
int  cad_report_summarize_body(const ReportParams *params, tag_t body_tag);

#endif
