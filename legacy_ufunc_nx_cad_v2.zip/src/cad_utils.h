#ifndef CAD_UTILS_H_INCLUDED
#define CAD_UTILS_H_INCLUDED

#include <uf.h>
#include <uf_ui.h>

/* Legacy-style utilities for logging and unit handling.
   Designed to be migrated into a modern utility/service layer. */

void cad_utils_open_listing_window(void);
void cad_utils_log(const char *message);
void cad_utils_log_double(const char *label, double value);
void cad_utils_log_int(const char *label, int value);

/* Simple INI-style template reader.
   NOTE: This is a very naive parser for demonstration. */
int cad_utils_read_template_value(const char *section,
                                  const char *key,
                                  double *out_value);

/* Batch job file helpers */
void cad_utils_log_header(const char *title);

#endif
