#include "cad_utils.h"
#include <stdio.h>
#include <string.h>

#define CONFIG_FILE "config/templates.ini"

void cad_utils_open_listing_window(void)
{
    UF_UI_open_listing_window();
}

void cad_utils_log(const char *message)
{
    UF_UI_write_listing_window(message);
    UF_UI_write_listing_window("\n");
}

void cad_utils_log_double(const char *label, double value)
{
    char buffer[256];
    sprintf(buffer, "%s: %f\n", label, value);
    UF_UI_write_listing_window(buffer);
}

void cad_utils_log_int(const char *label, int value)
{
    char buffer[256];
    sprintf(buffer, "%s: %d\n", label, value);
    UF_UI_write_listing_window(buffer);
}

int cad_utils_read_template_value(const char *section,
                                  const char *key,
                                  double *out_value)
{
    FILE *fp = fopen(CONFIG_FILE, "r");
    if (!fp)
        return 1;

    char line[256];
    char current_section[128] = {0};
    int found_section = 0;

    while (fgets(line, sizeof(line), fp))
    {
        // Trim leading spaces
        char *p = line;
        while (*p == ' ' || *p == '\t') p++;

        if (*p == '#' || *p == ';' || *p == '\n' || *p == '\0')
            continue;

        if (*p == '[')
        {
            char sec[128];
            if (sscanf(p, "[%127[^]]", sec) == 1)
            {
                strcpy(current_section, sec);
                found_section = (strcmp(current_section, section) == 0);
            }
            continue;
        }

        if (!found_section)
            continue;

        char k[128];
        double v;
        if (sscanf(p, "%127[^=]=%lf", k, &v) == 2)
        {
            // strip whitespace
            char *end = k + strlen(k) - 1;
            while (end > k && (*end == ' ' || *end == '\t')) { *end = '\0'; end--; }

            if (strcmp(k, key) == 0)
            {
                *out_value = v;
                fclose(fp);
                return 0;
            }
        }
    }

    fclose(fp);
    return 1;
}

void cad_utils_log_header(const char *title)
{
    cad_utils_log("================================");
    cad_utils_log(title);
    cad_utils_log("================================");
}
