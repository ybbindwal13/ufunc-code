#ifndef CAD_BOLT_CIRCLE_H_INCLUDED
#define CAD_BOLT_CIRCLE_H_INCLUDED

#include <uf.h>

typedef struct BoltCircleParams_s
{
    double radius;
    double hole_diameter;
    int hole_count;
} BoltCircleParams;

void cad_bolt_circle_get_default_params(BoltCircleParams *params);
int  cad_bolt_circle_prompt_user_for_params(BoltCircleParams *params);
int  cad_bolt_circle_create_on_face(const BoltCircleParams *params, tag_t face_tag);

#endif
