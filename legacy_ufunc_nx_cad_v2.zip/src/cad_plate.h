#ifndef CAD_PLATE_H_INCLUDED
#define CAD_PLATE_H_INCLUDED

#include <uf.h>

/* Parametric plate with a grid of through holes.
   This module is intentionally procedural and heavily coupled
   to the NX UF modeling API to serve as a modernization candidate. */

typedef struct PlateParams_s
{
    double width;
    double height;
    double thickness;
    double hole_diameter;
    int hole_rows;
    int hole_cols;
} PlateParams;

void cad_plate_get_default_params(PlateParams *params);
int  cad_plate_prompt_user_for_params(PlateParams *params);
int  cad_plate_create(const PlateParams *params, tag_t *plate_tag);

#endif
