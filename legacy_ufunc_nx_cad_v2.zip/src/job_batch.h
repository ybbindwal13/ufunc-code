#ifndef JOB_BATCH_H_INCLUDED
#define JOB_BATCH_H_INCLUDED

/* Batch job runner reading operations from config/jobs.csv.
   This module is a good candidate for migration to a background
   job processor or queue-based .NET service. */

void job_batch_run_all(void);

#endif
