#ifndef UI_MENU_H_INCLUDED
#define UI_MENU_H_INCLUDED

/* Legacy-style textual menu using NX UF UI APIs.
   This is the main interaction point with the user and is a good
   candidate to be replaced by a modern React-based UI. */

void ui_menu_show_main_menu(void);

#endif
