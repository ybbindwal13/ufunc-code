#include <uf.h>
#include <uf_ui.h>

#include "ui_menu.h"
#include "cad_utils.h"

/* 
 * Legacy NX/UG UFunc entry point.
 * This is the procedural starting point that would be replaced by
 * a modern .NET service entry or a REST API gateway.
 */

void ufusr(char *param, int *retcode, int param_len)
{
    int ifail = UF_initialize();
    if (ifail != 0)
    {
        UF_UI_open_listing_window();
        UF_UI_write_listing_window("Failed to initialize UF.\n");
        *retcode = ifail;
        return;
    }

    ui_menu_show_main_menu();

    UF_terminate();
    *retcode = 0;
}

void ufusr_ask_unload(int *unload_option)
{
    // Unload immediately after execution
    *unload_option = UF_UNLOAD_IMMEDIATELY;
}
