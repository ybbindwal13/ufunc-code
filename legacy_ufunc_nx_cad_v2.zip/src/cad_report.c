#include "cad_report.h"
#include "cad_utils.h"
#include <uf_modl.h>
#include <uf_ui.h>
#include <stdio.h>

void cad_report_get_default_params(ReportParams *params)
{
    double tmp;
    if (cad_utils_read_template_value("report_default", "density", &tmp) == 0)
        params->density = tmp;
    else
        params->density = 7.85;
}

static int prompt_double_rep(const char *message, double default_val, double *out_val)
{
    char prompt[256];
    char response[256];
    sprintf(prompt, "%s (default %.2f):", message, default_val);
    int resp = UF_UI_ask_string(prompt, response);
    if (resp != 0 || response[0] == '\0')
    {
        *out_val = default_val;
        return 0;
    }
    if (sscanf(response, "%lf", out_val) != 1)
    {
        *out_val = default_val;
    }
    return 0;
}

int cad_report_prompt_user_for_params(ReportParams *params)
{
    cad_utils_log_header("Report Parameters");
    prompt_double_rep("Material density", params->density, &params->density);
    cad_utils_log_double("Density", params->density);
    return 0;
}

int cad_report_summarize_body(const ReportParams *params, tag_t body_tag)
{
    if (body_tag == NULL_TAG)
    {
        cad_utils_log("No body selected for report.");
        return 1;
    }

    // Very simplified mass properties reporting
    cad_utils_log("Reporting mass properties (simplified placeholder).");
    cad_utils_log_double("Density used", params->density);

    // Real NX code would call UF_MODL_ask_mass_props etc.

    return 0;
}
