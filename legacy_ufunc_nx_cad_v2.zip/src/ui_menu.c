#include "ui_menu.h"
#include "cad_utils.h"
#include "cad_plate.h"
#include "cad_bolt_circle.h"
#include "cad_edge_ops.h"
#include "cad_report.h"
#include "job_batch.h"

#include <uf.h>
#include <uf_ui.h>
#include <uf_modl.h>
#include <stdio.h>

static void create_plate_flow(void)
{
    PlateParams params;
    cad_plate_get_default_params(&params);
    cad_plate_prompt_user_for_params(&params);
    tag_t plate_tag = NULL_TAG;
    if (cad_plate_create(&params, &plate_tag) == 0)
    {
        cad_utils_log("Plate created successfully.");
    }
}

static void create_bolt_circle_flow(void)
{
    BoltCircleParams params;
    cad_bolt_circle_get_default_params(&params);
    cad_bolt_circle_prompt_user_for_params(&params);

    // Ask user to pick a face (simplified)
    int resp;
    tag_t object;
    double cursor[3];
    int view;
    resp = UF_UI_pick_single("Select face for bolt circle", &object, cursor, &view);
    if (resp != 0)
    {
        cad_utils_log("No face picked.");
        return;
    }

    cad_bolt_circle_create_on_face(&params, object);
}

static void edge_ops_flow(void)
{
    EdgeOpsParams params;
    cad_edge_ops_get_default_params(&params);
    cad_edge_ops_prompt_user_for_params(&params);

    // Ask user to pick a body (simplified)
    int resp;
    tag_t object;
    double cursor[3];
    int view;
    resp = UF_UI_pick_single("Select solid body for edge operations", &object, cursor, &view);
    if (resp != 0)
    {
        cad_utils_log("No body picked.");
        return;
    }

    cad_edge_ops_apply_to_body(&params, object);
}

static void report_flow(void)
{
    ReportParams params;
    cad_report_get_default_params(&params);
    cad_report_prompt_user_for_params(&params);

    int resp;
    tag_t object;
    double cursor[3];
    int view;
    resp = UF_UI_pick_single("Select solid body for report", &object, cursor, &view);
    if (resp != 0)
    {
        cad_utils_log("No body picked.");
        return;
    }

    cad_report_summarize_body(&params, object);
}

static void batch_jobs_flow(void)
{
    job_batch_run_all();
}

void ui_menu_show_main_menu(void)
{
    cad_utils_open_listing_window();
    cad_utils_log("=== Legacy NX UFunc CAD Tool (v2) ===");
    cad_utils_log("1) Create parametric plate with holes");
    cad_utils_log("2) Create bolt circle on selected face");
    cad_utils_log("3) Apply edge operations (chamfer/fillet) to body");
    cad_utils_log("4) Report mass properties (simplified)");
    cad_utils_log("5) Run batch jobs from config/jobs.csv");
    cad_utils_log("Q) Quit");

    char response[64];
    int rc = UF_UI_ask_string("Enter choice (1/2/3/4/5/Q):", response);
    if (rc != 0)
        return;

    if (response[0] == '1')
    {
        create_plate_flow();
    }
    else if (response[0] == '2')
    {
        create_bolt_circle_flow();
    }
    else if (response[0] == '3')
    {
        edge_ops_flow();
    }
    else if (response[0] == '4')
    {
        report_flow();
    }
    else if (response[0] == '5')
    {
        batch_jobs_flow();
    }
    else
    {
        cad_utils_log("Exiting menu.");
    }
}
