#include "job_batch.h"
#include "cad_plate.h"
#include "cad_bolt_circle.h"
#include "cad_edge_ops.h"
#include "cad_utils.h"

#include <stdio.h>
#include <string.h>

#define JOB_FILE "config/jobs.csv"

void job_batch_run_all(void)
{
    FILE *fp = fopen(JOB_FILE, "r");
    if (!fp)
    {
        cad_utils_log("No jobs.csv file found.");
        return;
    }

    cad_utils_log_header("Batch Job Runner");

    char line[256];
    while (fgets(line, sizeof(line), fp))
    {
        // skip comments/blank
        char *p = line;
        while (*p == ' ' || *p == '\t') p++;
        if (*p == '#' || *p == '\n' || *p == '\0')
            continue;

        char job_type[32];
        double p1, p2, p3, p4, p5;
        int parsed = sscanf(p, "%31[^;];%lf;%lf;%lf;%lf;%lf", job_type, &p1, &p2, &p3, &p4, &p5);
        if (parsed < 2)
            continue;

        if (strcmp(job_type, "plate") == 0 && parsed >= 6)
        {
            PlateParams params;
            params.width = p1;
            params.height = p2;
            params.thickness = p3;
            params.hole_diameter = p4;
            int rows = (int)(p5 / 1000);
            int cols = (int)(p5 - rows * 1000);
            params.hole_rows = rows;
            params.hole_cols = cols;

            cad_utils_log("Running batch plate job...");
            cad_utils_log_double("Width", params.width);
            cad_utils_log_double("Height", params.height);
            cad_utils_log_double("Thickness", params.thickness);
            cad_utils_log_int("Rows", params.hole_rows);
            cad_utils_log_int("Cols", params.hole_cols);

            cad_plate_create(&params, NULL);
        }
        else if (strcmp(job_type, "bolt_circle") == 0 && parsed >= 5)
        {
            BoltCircleParams bc;
            bc.radius = p1;
            bc.hole_diameter = p2;
            bc.hole_count = (int)p3;
            cad_utils_log("Running batch bolt circle job...");
            cad_utils_log_double("Radius", bc.radius);
            cad_utils_log_double("Hole diameter", bc.hole_diameter);
            cad_utils_log_int("Hole count", bc.hole_count);
            cad_bolt_circle_create_on_face(&bc, NULL_TAG); // simplified
        }
        else if (strcmp(job_type, "edge") == 0 && parsed >= 4)
        {
            EdgeOpsParams ep;
            ep.chamfer_size = p1;
            ep.fillet_radius = p2;
            cad_utils_log("Running batch edge ops job...");
            cad_utils_log_double("Chamfer size", ep.chamfer_size);
            cad_utils_log_double("Fillet radius", ep.fillet_radius);
            cad_edge_ops_apply_to_body(&ep, NULL_TAG); // simplified
        }
    }

    fclose(fp);
    cad_utils_log("Batch jobs completed.");
}
