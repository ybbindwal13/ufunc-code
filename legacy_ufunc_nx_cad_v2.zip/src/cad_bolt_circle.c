#include "cad_bolt_circle.h"
#include "cad_utils.h"
#include <uf_ui.h>
#include <uf_modl.h>
#include <math.h>
#include <stdio.h>

void cad_bolt_circle_get_default_params(BoltCircleParams *params)
{
    double tmp;
    if (cad_utils_read_template_value("bolt_circle_default", "radius", &tmp) == 0)
        params->radius = tmp;
    else
        params->radius = 50.0;

    if (cad_utils_read_template_value("bolt_circle_default", "hole_diameter", &tmp) == 0)
        params->hole_diameter = tmp;
    else
        params->hole_diameter = 12.0;

    if (cad_utils_read_template_value("bolt_circle_default", "hole_count", &tmp) == 0)
        params->hole_count = (int)tmp;
    else
        params->hole_count = 8;
}

static int prompt_double_bc(const char *message, double default_val, double *out_val)
{
    char prompt[256];
    char response[256];
    sprintf(prompt, "%s (default %.2f):", message, default_val);
    int resp = UF_UI_ask_string(prompt, response);
    if (resp != 0 || response[0] == '\0')
    {
        *out_val = default_val;
        return 0;
    }
    if (sscanf(response, "%lf", out_val) != 1)
    {
        *out_val = default_val;
    }
    return 0;
}

static int prompt_int_bc(const char *message, int default_val, int *out_val)
{
    char prompt[256];
    char response[256];
    sprintf(prompt, "%s (default %d):", message, default_val);
    int resp = UF_UI_ask_string(prompt, response);
    if (resp != 0 || response[0] == '\0')
    {
        *out_val = default_val;
        return 0;
    }
    if (sscanf(response, "%d", out_val) != 1)
    {
        *out_val = default_val;
    }
    return 0;
}

int cad_bolt_circle_prompt_user_for_params(BoltCircleParams *params)
{
    cad_utils_log_header("Bolt Circle Parameters");
    prompt_double_bc("Bolt circle radius", params->radius, &params->radius);
    prompt_double_bc("Hole diameter", params->hole_diameter, &params->hole_diameter);
    prompt_int_bc("Hole count", params->hole_count, &params->hole_count);

    cad_utils_log_double("Radius", params->radius);
    cad_utils_log_double("Hole diameter", params->hole_diameter);
    cad_utils_log_int("Hole count", params->hole_count);

    return 0;
}

int cad_bolt_circle_create_on_face(const BoltCircleParams *params, tag_t face_tag)
{
    if (face_tag == NULL_TAG)
    {
        cad_utils_log("No face selected for bolt circle.");
        return 1;
    }

    // For simplicity, we place holes around origin in XY plane.
    // In real code, we would project onto the face and handle orientation.
    double radius = params->radius;
    double hole_radius = params->hole_diameter / 2.0;
    int n = params->hole_count;
    if (n < 1)
        return 1;

    char buf[256];
    sprintf(buf, "Creating bolt circle with %d holes on face %d", n, face_tag);
    cad_utils_log(buf);

    for (int i = 0; i < n; ++i)
    {
        double angle = (2.0 * 3.141592653589793 * i) / (double)n;
        double center[3];
        center[0] = radius * cos(angle);
        center[1] = radius * sin(angle);
        center[2] = 0.0;

        double dir[3] = {0.0, 0.0, 1.0};
        tag_t cyl_feature = NULL_TAG;
        int ifail = UF_MODL_create_cyl1(UF_NULLSIGN, center, dir, hole_radius, 20.0, &cyl_feature);
        if (ifail != 0)
        {
            cad_utils_log("Failed to create bolt circle cylinder feature.");
        }
    }

    cad_utils_log("Bolt circle creation done.");
    return 0;
}
