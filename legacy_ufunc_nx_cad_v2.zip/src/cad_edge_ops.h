#ifndef CAD_EDGE_OPS_H_INCLUDED
#define CAD_EDGE_OPS_H_INCLUDED

#include <uf.h>

typedef struct EdgeOpsParams_s
{
    double chamfer_size;
    double fillet_radius;
} EdgeOpsParams;

void cad_edge_ops_get_default_params(EdgeOpsParams *params);
int  cad_edge_ops_prompt_user_for_params(EdgeOpsParams *params);
int  cad_edge_ops_apply_to_body(const EdgeOpsParams *params, tag_t body_tag);

#endif
