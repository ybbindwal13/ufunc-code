#include "cad_edge_ops.h"
#include "cad_utils.h"
#include <uf_ui.h>
#include <uf_modl.h>
#include <stdio.h>

void cad_edge_ops_get_default_params(EdgeOpsParams *params)
{
    double tmp;
    if (cad_utils_read_template_value("edge_ops_default", "chamfer_size", &tmp) == 0)
        params->chamfer_size = tmp;
    else
        params->chamfer_size = 2.0;

    if (cad_utils_read_template_value("edge_ops_default", "fillet_radius", &tmp) == 0)
        params->fillet_radius = tmp;
    else
        params->fillet_radius = 5.0;
}

static int prompt_double_edge(const char *message, double default_val, double *out_val)
{
    char prompt[256];
    char response[256];
    sprintf(prompt, "%s (default %.2f):", message, default_val);
    int resp = UF_UI_ask_string(prompt, response);
    if (resp != 0 || response[0] == '\0')
    {
        *out_val = default_val;
        return 0;
    }
    if (sscanf(response, "%lf", out_val) != 1)
    {
        *out_val = default_val;
    }
    return 0;
}

int cad_edge_ops_prompt_user_for_params(EdgeOpsParams *params)
{
    cad_utils_log_header("Edge Operations Parameters");
    prompt_double_edge("Chamfer size", params->chamfer_size, &params->chamfer_size);
    prompt_double_edge("Fillet radius", params->fillet_radius, &params->fillet_radius);

    cad_utils_log_double("Chamfer size", params->chamfer_size);
    cad_utils_log_double("Fillet radius", params->fillet_radius);
    return 0;
}

int cad_edge_ops_apply_to_body(const EdgeOpsParams *params, tag_t body_tag)
{
    if (body_tag == NULL_TAG)
    {
        cad_utils_log("No body selected for edge operations.");
        return 1;
    }

    // This is a simplified placeholder logic.
    cad_utils_log("Applying chamfer and fillet operations to body.");
    cad_utils_log_double("Chamfer size", params->chamfer_size);
    cad_utils_log_double("Fillet radius", params->fillet_radius);

    // Real NX code would collect edges and call UF_MODL_create_chamfer / UF_MODL_create_fillet.
    // Here we only log intentions to keep the example readable.

    return 0;
}
