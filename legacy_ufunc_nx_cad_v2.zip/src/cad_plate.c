#include "cad_plate.h"
#include "cad_utils.h"
#include <uf_ui.h>
#include <uf_modl.h>
#include <stdio.h>

void cad_plate_get_default_params(PlateParams *params)
{
    double tmp;
    if (cad_utils_read_template_value("plate_default", "width", &tmp) == 0)
        params->width = tmp;
    else
        params->width = 100.0;

    if (cad_utils_read_template_value("plate_default", "height", &tmp) == 0)
        params->height = tmp;
    else
        params->height = 80.0;

    if (cad_utils_read_template_value("plate_default", "thickness", &tmp) == 0)
        params->thickness = tmp;
    else
        params->thickness = 10.0;

    if (cad_utils_read_template_value("plate_default", "hole_diameter", &tmp) == 0)
        params->hole_diameter = tmp;
    else
        params->hole_diameter = 10.0;

    if (cad_utils_read_template_value("plate_default", "hole_rows", &tmp) == 0)
        params->hole_rows = (int)tmp;
    else
        params->hole_rows = 2;

    if (cad_utils_read_template_value("plate_default", "hole_cols", &tmp) == 0)
        params->hole_cols = (int)tmp;
    else
        params->hole_cols = 3;
}

static int prompt_double(const char *message, double default_val, double *out_val)
{
    char prompt[256];
    char response[256];
    sprintf(prompt, "%s (default %.2f):", message, default_val);
    int resp = UF_UI_ask_string(prompt, response);
    if (resp != 0 || response[0] == '\0')
    {
        *out_val = default_val;
        return 0;
    }
    if (sscanf(response, "%lf", out_val) != 1)
    {
        *out_val = default_val;
    }
    return 0;
}

static int prompt_int(const char *message, int default_val, int *out_val)
{
    char prompt[256];
    char response[256];
    sprintf(prompt, "%s (default %d):", message, default_val);
    int resp = UF_UI_ask_string(prompt, response);
    if (resp != 0 || response[0] == '\0')
    {
        *out_val = default_val;
        return 0;
    }
    if (sscanf(response, "%d", out_val) != 1)
    {
        *out_val = default_val;
    }
    return 0;
}

int cad_plate_prompt_user_for_params(PlateParams *params)
{
    cad_utils_open_listing_window();
    cad_utils_log_header("Plate Parameters");

    prompt_double("Plate width", params->width, &params->width);
    prompt_double("Plate height", params->height, &params->height);
    prompt_double("Plate thickness", params->thickness, &params->thickness);
    prompt_double("Hole diameter", params->hole_diameter, &params->hole_diameter);
    prompt_int("Hole rows", params->hole_rows, &params->hole_rows);
    prompt_int("Hole columns", params->hole_cols, &params->hole_cols);

    cad_utils_log("Parameters after user input:");
    cad_utils_log_double("Width", params->width);
    cad_utils_log_double("Height", params->height);
    cad_utils_log_double("Thickness", params->thickness);
    cad_utils_log_double("Hole diameter", params->hole_diameter);
    cad_utils_log_int("Rows", params->hole_rows);
    cad_utils_log_int("Columns", params->hole_cols);

    return 0;
}

int cad_plate_create(const PlateParams *params, tag_t *plate_tag)
{
    int ifail = 0;
    UF_FEATURE_SIGN sign = UF_NULLSIGN;
    double block_origin[3] = {0.0, 0.0, 0.0};
    double block_edge[3] = {params->width, params->height, params->thickness};

    tag_t block_feature = NULL_TAG;
    ifail = UF_MODL_create_block1(sign, block_origin, block_edge, &block_feature);
    if (ifail != 0)
    {
        cad_utils_log("Failed to create plate block.");
        return ifail;
    }

    // Create a grid of holes
    double dx = params->width / (params->hole_cols + 1);
    double dy = params->height / (params->hole_rows + 1);
    double radius = params->hole_diameter / 2.0;

    char buffer[256];
    sprintf(buffer, "Creating holes: rows=%d cols=%d", params->hole_rows, params->hole_cols);
    cad_utils_log(buffer);

    for (int r = 0; r < params->hole_rows; ++r)
    {
        for (int c = 0; c < params->hole_cols; ++c)
        {
            double center[3];
            center[0] = (c + 1) * dx;
            center[1] = (r + 1) * dy;
            center[2] = params->thickness / 2.0;

            // Simplified: create a cylinder and subtract it using boolean
            tag_t cyl_feature = NULL_TAG;
            double cyl_dir[3] = {0.0, 0.0, 1.0};
            ifail = UF_MODL_create_cyl1(UF_NULLSIGN, center, cyl_dir, radius,
                                        params->thickness * 1.5, &cyl_feature);
            if (ifail != 0)
            {
                cad_utils_log("Failed to create hole cylinder.");
                continue;
            }

            // Real code would perform a boolean subtract between block and cylinder.
        }
    }

    if (plate_tag)
        *plate_tag = block_feature;

    cad_utils_log("Plate feature creation completed.");
    return 0;
}
