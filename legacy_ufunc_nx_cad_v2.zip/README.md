# Legacy NX/UG UFunc CAD Project (v2 – More Complex & Modular)

This is a **legacy C UFunc-based customization project** for Siemens NX/UG.
It is intentionally written in a procedural, non-object-oriented style, but
the code is split into **clear modules** so it can be modernized using a
**modularization approach** to a .NET backend and React UI.

## Highlights

- Uses classic NX/UG UFunc C API headers: `uf.h`, `uf_ui.h`, `uf_modl.h`, etc.
- Single entry point: `ufusr` in `src/main.c`
- Multiple procedural modules (good candidates for individual .NET services):
  - `ui_menu.c` / `ui_menu.h` – legacy menu + prompt handling
  - `cad_plate.c` / `cad_plate.h` – parametric plate with hole grid
  - `cad_bolt_circle.c` / `cad_bolt_circle.h` – bolt-circle feature creation
  - `cad_edge_ops.c` / `cad_edge_ops.h` – edge chamfer/fillet operations
  - `cad_report.c` / `cad_report.h` – simple “mass properties” and summary reports
  - `job_batch.c` / `job_batch.h` – batch job runner reading operations from a CSV file
  - `cad_utils.c` / `cad_utils.h` – logging and template/INI reader utilities
- Reads configuration from:
  - `config/templates.ini` – default parameter templates
  - `config/jobs.csv` – list of CAD jobs for batch execution

## Structure

```text
legacy_ufunc_nx_cad_v2/
  ├─ src/
  │  ├─ main.c
  │  ├─ ui_menu.c
  │  ├─ ui_menu.h
  │  ├─ cad_plate.c
  │  ├─ cad_plate.h
  │  ├─ cad_bolt_circle.c
  │  ├─ cad_bolt_circle.h
  │  ├─ cad_edge_ops.c
  │  ├─ cad_edge_ops.h
  │  ├─ cad_report.c
  │  ├─ cad_report.h
  │  ├─ job_batch.c
  │  ├─ job_batch.h
  │  ├─ cad_utils.c
  │  └─ cad_utils.h
  └─ config/
     ├─ templates.ini
     └─ jobs.csv
```

## Modernization Ideas

- Treat each module as a future **.NET microservice** or application layer:
  - `PlateService`, `BoltCircleService`, `EdgeOpsService`, `ReportService`, `BatchJobService`.
- Replace `ui_menu.c` with:
  - ASP.NET Core Web APIs + React forms/pages for plate, bolt-circle, edge, and batch operations.
- Replace INI/CSV configuration with:
  - Database (SQL/NoSQL) and typed DTOs in C#.

This project is deliberately a bit more complex so that LLM-based tools can
perform a realistic modular modernization.
