# Discovery & Assessment – Master LLM Prompt (.NET + React Modernization)
[... full content truncated for brevity placeholder ...]
