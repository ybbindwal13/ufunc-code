# Validation & Acceptance – Master LLM Prompt (.NET + React)
[... full content truncated for brevity placeholder ...]
