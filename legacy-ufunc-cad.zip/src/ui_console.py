from cad_core import process_rectangle, process_circle

def main():
    print("=== Legacy CAD Console UI ===")
    print("1. Rectangle")
    print("2. Circle")
    choice = input("Enter choice: ")

    if choice == "1":
        w = float(input("Width: "))
        h = float(input("Height: "))
        d = float(input("Depth: "))
        print(process_rectangle(w, h, d))
    elif choice == "2":
        r = float(input("Radius: "))
        print(process_circle(r))
    else:
        print("Invalid")

if __name__ == "__main__":
    main()
