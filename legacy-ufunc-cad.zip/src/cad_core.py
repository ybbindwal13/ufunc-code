from cad_ufuncs import *

def process_rectangle(width, height, depth):
    return {
        "area": ufunc_calculate_area(width, height),
        "perimeter": ufunc_calculate_perimeter(width, height),
        "volume": ufunc_extrude_2d_shape(width, height, depth)
    }

def process_circle(radius):
    area, circum = ufunc_calculate_circle(radius)
    return {"area": area, "circumference": circum}
