import math

def ufunc_calculate_area(width, height):
    return width * height

def ufunc_calculate_perimeter(width, height):
    return 2 * (width + height)

def ufunc_extrude_2d_shape(width, height, depth):
    area = ufunc_calculate_area(width, height)
    return area * depth

def ufunc_calculate_circle(radius):
    area = math.pi * radius * radius
    circumference = 2 * math.pi * radius
    return area, circumference
