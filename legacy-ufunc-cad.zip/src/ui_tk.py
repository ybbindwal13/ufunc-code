import tkinter as tk
from cad_core import process_rectangle

def calculate():
    w = float(entry_w.get())
    h = float(entry_h.get())
    d = float(entry_d.get())
    result = process_rectangle(w, h, d)
    output.set(f"Area: {result['area']}\nPerimeter: {result['perimeter']}\nVolume: {result['volume']}")

root = tk.Tk()
root.title("Legacy CAD Tool")

tk.Label(root, text="Width").pack()
entry_w = tk.Entry(root); entry_w.pack()
tk.Label(root, text="Height").pack()
entry_h = tk.Entry(root); entry_h.pack()
tk.Label(root, text="Depth").pack()
entry_d = tk.Entry(root); entry_d.pack()
tk.Button(root, text="Compute", command=calculate).pack()
output = tk.StringVar()
tk.Label(root, textvariable=output).pack()
root.mainloop()
